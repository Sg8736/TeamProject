﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;


namespace TeamProject
{
    public partial class SignUpForm : Form
    {
        private DBClass dbClass;

        public SignUpForm()
        {
            InitializeComponent();
            dbClass = new DBClass();
        }

        private void InitializeEmailDomains()
        {
            // ComboBox에 도메인을 추가합니다.
            lstEmailDomains.Items.Add("gmail.com");
            lstEmailDomains.Items.Add("naver.com");
            lstEmailDomains.Items.Add("bc.ac.kr");
            // 필요한 만큼 도메인을 추가할 수 있습니다.
        }

        private void SignUpForm_Load(object sender, EventArgs e)
        {
            // 폼이 로드될 때 도메인 초기화를 수행합니다.
            InitializeEmailDomains();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dbClass.ConnectToDatabase())
            {
                try
                {
                    string userId = txtid.Text;
                    string phoneNumber = $"{txtphone1.Text}-{txtphone2.Text}-{txtphone3.Text}";
                    string emailDomain = lstEmailDomains.SelectedItem?.ToString();

                    // 이메일 도메인이 선택되지 않았거나 빈 경우에 대한 처리
                    if (string.IsNullOrWhiteSpace(emailDomain))
                    {
                        MessageBox.Show("이메일 도메인을 선택하세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    string email = $"{txtemail.Text}@{emailDomain}";

                    string duplicateInfo = dbClass.CheckDuplicateUserInfo(userId, phoneNumber, email);

                    if (duplicateInfo != null)
                    {
                        MessageBox.Show(duplicateInfo, "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        // 회원가입 처리
                        if (dbClass.RegisterUser(userId, txtpwd.Text, txtname.Text, txtaddress.Text, phoneNumber, email))
                        {
                            MessageBox.Show("회원가입 완료");
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("회원가입 실패");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    // 연결 안전하게 해제
                    dbClass.DisconnectFromDatabase();
                }
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}