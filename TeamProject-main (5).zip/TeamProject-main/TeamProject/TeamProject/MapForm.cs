﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeamProject
{
    public partial class MapForm : Form
    {
        private string OrderLocation;
        private MypageForm parentForm;
        public MapForm(MypageForm parentForm)
        {
            InitializeComponent();
            this.parentForm = parentForm;
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                //엔터를 누르면 버튼을 누른다는 뜻
                button1.PerformClick();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<Locale> locales = KakaoApi.Search(textBox1.Text);
            listBox1.Items.Clear();
            foreach (Locale locale in locales)
            {
                listBox1.Items.Add(locale);
            }
        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1 == null || listBox1.SelectedIndex == -1)
                return;

            Locale ml = listBox1.SelectedItem as Locale;
            if (ml != null)
            {
                Locale selectedLocale = listBox1.SelectedItem as Locale;

                // 선택한 Locale 객체의 Name 값을 TextBox2에 표시
                textBox2.Text = selectedLocale.Name;

                object[] pos = new object[] { ml.Lat, ml.Lng };
                HtmlDocument hdoc = webBrowser1.Document;
                if (hdoc != null)
                {
                    hdoc.InvokeScript("setCenter", pos);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OrderLocation = textBox2.Text;

            // 다이얼로그로 예 아니오 나타내기
            DialogResult result = MessageBox.Show("배달을 완료하시겠습니까?", "확인", MessageBoxButtons.YesNo);

            // 사용자가 확인을 선택한 경우
            if (result == DialogResult.Yes)
            {
                // 주소를 선택한 이벤트로 전달
                if (listBox1.SelectedIndex != -1)
                {
                    // 여기서 DriverOrderLocation을 DriverForm에 전달
                    parentForm.ReceiveDriverOrderLocation(OrderLocation);

                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("배달 완료를 취소하였습니다.");
            }
        }


        public void SetLocationAndSearch(string deliveryAddress)
        {
            button2.Visible = false;
            textBox2.Visible = false;

            // webBrowser1 크기 변경
            webBrowser1.Size = new Size(960, 446);
            webBrowser1.Location = new Point(12, 12);

            textBox1.Text = deliveryAddress;

            List<Locale> locales = KakaoApi.Search(textBox1.Text);
            listBox1.Items.Clear();
            foreach (Locale locale in locales)
            {
                listBox1.Items.Add(locale);
            }

            if (locales.Count > 0)
            {

                // 선택한 아이템에 해당하는 위치로 지도 이동
                Locale ml = locales[0]; // 첫 번째 아이템 선택
                object[] pos = new object[] { ml.Lat, ml.Lng };
                HtmlDocument hdoc = webBrowser1.Document;
                if (hdoc != null)
                {
                    hdoc.InvokeScript("setCenter", pos);
                }
            }

            // 키보드 아래 키 한 번 누르기
            SendKeys.Send("{DOWN}");
        }
    }
}
