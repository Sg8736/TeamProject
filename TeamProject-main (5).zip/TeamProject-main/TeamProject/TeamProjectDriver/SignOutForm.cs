﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeamProjectDriver
{
    public partial class SignOutForm : Form
    {
        private DBClass dbClass;
        private string LoggedInDriverId;
        public event EventHandler LoggedOut;

        public SignOutForm(string loggedInDriverId)
        {
            InitializeComponent();
            dbClass = new DBClass();
            LoggedInDriverId = loggedInDriverId;

            // 로그인한 배달기사의 아이디를 읽기전용으로 표시
            txtid.Text = LoggedInDriverId;
            txtid.ReadOnly = true;
        }

        // 회원 탈퇴 성공 시 호출되는 메서드
        private void OnLoggedOut()
        {
            // LoggedOut 이벤트를 호출하여 로그아웃을 알립니다.
            LoggedOut?.Invoke(this, EventArgs.Empty);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string enteredPassword = txtpwd.Text;

            // 데이터베이스에 연결
            if (dbClass.ConnectToDatabase())
            {
                try
                {
                    // 비밀번호 확인
                    if (CheckPassword(enteredPassword))
                    {
                        DialogResult result = MessageBox.Show("회원 탈퇴를 진행하시겠습니까?", "확인", MessageBoxButtons.YesNo);

                        if (result == DialogResult.Yes)
                        {
                            // 회원 탈퇴 성공 메시지
                            MessageBox.Show("회원 탈퇴 성공 지금까지 감사했습니다.");

                            // 로그인한 driverId의 값을 가진 DriverOrders 테이블에서 레코드 삭제
                            DeleteFromDriverOrders(LoggedInDriverId);

                            // 로그인한 driverId의 값을 가진 DriverInfo 테이블에서 레코드 삭제
                            DeleteFromDriverInfo(LoggedInDriverId);

                            // 로그아웃을 호출하여 로그인 상태를 갱신합니다.
                            OnLoggedOut();

                            // 폼 닫기
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("회원 탈퇴를 취소했습니다.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("비밀번호가 틀렸습니다.");
                    }
                }
                finally
                {
                    // 데이터베이스 연결 해제
                    dbClass.DisconnectFromDatabase();
                }
            }
            else
            {
                MessageBox.Show("데이터베이스에 연결할 수 없습니다.");
            }
        }
        private bool CheckPassword(string enteredPassword)
        {
            try
            {
                // DriverInfo 테이블에서 비밀번호 가져오기
                string query = $"SELECT dPassword FROM DriverInfo WHERE driverId = '{LoggedInDriverId}'";
                dbClass.DCom.CommandText = query;

                string correctPassword = dbClass.DCom.ExecuteScalar().ToString();

                // 입력한 비밀번호와 저장된 비밀번호 비교
                return enteredPassword == correctPassword;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"비밀번호 확인 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
                return false;
            }
        }

        private void DeleteFromDriverOrders(string driverId)
        {
            try
            {
                // DriverOrders 테이블에서 해당 driverId의 레코드 삭제
                string deleteQuery = $"DELETE FROM DriverOrders WHERE driverId = '{driverId}'";
                dbClass.DCom.CommandText = deleteQuery;
                dbClass.DCom.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"DriverOrders 삭제 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
        }

        private void DeleteFromDriverInfo(string driverId)
        {
            try
            {
                // DriverInfo 테이블에서 해당 driverId의 레코드 삭제
                string deleteQuery = $"DELETE FROM DriverInfo WHERE driverId = '{driverId}'";
                dbClass.DCom.CommandText = deleteQuery;
                dbClass.DCom.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"DriverInfo 삭제 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
        }
    }
}
