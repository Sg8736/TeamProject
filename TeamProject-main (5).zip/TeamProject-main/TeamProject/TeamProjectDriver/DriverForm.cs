﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;

namespace TeamProjectDriver
{
    public partial class DriverForm : Form
    {
        private DBClass dbClass;
        private GroupBox userControlsGroupBox;
        private TextBox loggedInTextBox;
        private Button logoutButton;
        private Button loginButton;

        private string orderId;
        private string loggedInDriverId; // 추가: 로그인한 driverId 저장
        public string ReceivedDriverOrderLocation { get; set; }
        public string LoggedInDriverId { get; private set; }
        private bool isLoggedIn = false;
        public string SelectedOrderId { get; set; }
        // mapForm 필드 정의
        private MapForm mapForm;

        public DriverForm()
        {
            InitializeComponent();
            dbClass = new DBClass();
            userControlsGroupBox = LoginGroup;

            loginButton = LoginBtn;
            loginButton.Click -= LoginButton_Click;
            loginButton.Click += LoginButton_Click;

            // mapForm 초기화
            mapForm = new MapForm(this);
        }


        // = = = = = = = = = = = = = = = = 로그인 회원 가입 기능= = = = = = = = = = = = = = = =
        private void LoginButton_Click(object sender, EventArgs e)
        {
            LoginForm loginForm = new LoginForm();
            loginForm.ShowDialog();

            if (loginForm.LoginSuccess)
            {
                LoggedInDriverId = loginForm.LoggedInDriverId;

                UpdateUIOnLogin(loginForm.LoggedInDriverId);
            }
            else
            {
                MessageBox.Show("로그인에 실패했습니다.");
            }
        }

        private void ShowLoginSuccessMessage()
        {
            MessageBox.Show("환영합니다!");
        }

        private void SignUpButton_Click(object sender, EventArgs e)
        {
            AgreementForm agreementForm = new AgreementForm();
            agreementForm.ShowDialog();
        }

        private TextBox CreateTextBox()
        {
            TextBox textBox1 = new TextBox
            {
                ReadOnly = true,
                Location = new Point(12, 31)
            };

            this.Controls.Add(textBox1);
            return textBox1;
        }

        private Button CreateLogoutButton()
        {
            Button button = new Button
            {
                Text = "로그아웃",
                Location = new Point(112, 30)
            };

            button.Click += LogoutButton_Click;
            this.Controls.Add(button);
            return button;
        }

        private void LogoutButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("로그아웃 되었습니다.");

            loggedInTextBox.Visible = false;
            logoutButton.Visible = false;

            LoginBtn.Visible = true;
            SignUpBtn.Visible = true;

            // 주문 목록 감추기
            OrderDataGridView.DataSource = null;
            Orders_counter();

            DriverOrdersDataGridView.DataSource = null;
            DriverOrders_counter();


            DriverIdTxt.Text = null;
            DriverOrdersCompleteDataGridView.DataSource = null;
            DriverOrdersComplete_counter();

            SelcetOrderTxt.Text = null;
            DriverOrdertxt.Text = null;

            // 로그인 상태 갱신
            isLoggedIn = false;
        }

        private void UpdateUIOnLogin(string loggedInDriverId)
        {
            if (loggedInTextBox == null)
            {
                loggedInTextBox = CreateTextBox();
                userControlsGroupBox.Controls.Add(loggedInTextBox);
            }

            loggedInTextBox.Text = "ID: " + loggedInDriverId;
            loggedInTextBox.Visible = true;

            if (logoutButton == null)
            {
                logoutButton = CreateLogoutButton();
                userControlsGroupBox.Controls.Add(logoutButton);
            }

            // 로그인한 driverId 저장
            this.loggedInDriverId = loggedInDriverId;

            // DriverIdTxt에 로그인한 배달기사의 아이디 설정
            DriverIdTxt.Text = loggedInDriverId;

            // 로그인 상태 갱신
            isLoggedIn = true;

            logoutButton.Visible = true;

            LoginBtn.Visible = false;
            SignUpBtn.Visible = false;

            ShowLoginSuccessMessage();

            // 주문 목록 표시
            DisplayUserOrders();
            Orders_header();
            Orders_counter();

            // 픽업 배달 표시
            DisplayDriverOrders();
            DriverOrders_header();
            DriverOrders_counter();

            //완료한 배달기록 표시
            DisplayDriverOrdersComplete();
            DriverOrdersComplete_header();
            DriverOrdersComplete_counter();
        }
        // = = = = = = = = = = = = = = = = 로그인 회원 가입 기능= = = = = = = = = = = = = = = = 


        // 그리드 뷰 셀 클릭 이벤트 핸들러 등록
        private void DriverForm_Load(object sender, EventArgs e)
        {
            // DB 연결
            if (dbClass.ConnectToDatabase())
            {
                // inqDataGridView의 CellClick 이벤트 핸들러 등록
                OrderDataGridView.CellClick += OrdersDataGridView_CellClick;
                DriverOrdersDataGridView.CellClick += DriverOrdersDataGridView_CellClick;
            }
            else
            {
                MessageBox.Show("DB 연결에 실패했습니다.");
                this.Close();
            }
        }

        // 고객의 주문 목록 표시 기능
        public void Orders_counter()
        {
            int i = OrderDataGridView.RowCount;
            OrderCounter.Text = $"주문 : 총 {i} 개";
        }

        private void DisplayUserOrders()
        {
            // Orders 테이블을 사용하여 주문 목록을 가져오는 쿼리
            string sqlstr = $"SELECT * FROM Orders WHERE OrderStatus = '배달준비' ORDER BY orderId ASC";
            dbClass.DCom.CommandText = sqlstr;

            try
            {
                // ORDERS 테이블을 지우고, 주문 목록을 다시 채움
                if (dbClass.DS.Tables["Orders"] != null)
                {
                    dbClass.DS.Tables["Orders"].Clear(); // 중복 데이터 제거
                }

                dbClass.DA.SelectCommand = dbClass.DCom;
                dbClass.DA.Fill(dbClass.DS, "Orders");

                // DataGridView에 주문 목록 표시
                OrderDataGridView.DataSource = dbClass.DS.Tables["Orders"].DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"주문 목록 표시 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
        }

        public void Orders_header()
        {
            // Orders 테이블의 열 헤더 설정
            OrderDataGridView.Columns[0].HeaderText = "주문번호";
            OrderDataGridView.Columns[1].HeaderText = "주소";
            OrderDataGridView.Columns[2].HeaderText = "주문상태";
            OrderDataGridView.Columns[3].HeaderText = "총액";
            OrderDataGridView.Columns[4].HeaderText = "ID";

            // 각 열의 너비 설정
            OrderDataGridView.Columns[0].Width = 80;
            OrderDataGridView.Columns[1].Width = 150;
            OrderDataGridView.Columns[2].Width = 90;
            OrderDataGridView.Columns[3].Width = 70;
            OrderDataGridView.Columns[4].Width = 70;
        }

        // 새로 고침 버튼 기능
        private void ReloadBtn_Click(object sender, EventArgs e)
        {
            // 로그인 상태인 경우에만 주문 목록을 다시 불러오기
            if (isLoggedIn)
            {
                DisplayUserOrders();
                Orders_header();
                Orders_counter();
            }
        }

        // 주문 목록 그리드 뷰 셀 클릭 이벤트
        private void OrdersDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // OrderDataGridView가 null인지 확인
            if (OrderDataGridView == null)
            {
                // 그리드 뷰가 초기화되지 않았다면 초기화 코드를 추가하거나 오류를 처리하세요.
                MessageBox.Show("주문 목록 그리드 뷰가 초기화되지 않았습니다.");
                return;
            }

            // 그리드 뷰 행 인덱스가 유효한지 확인
            if (e.RowIndex >= 0 && e.RowIndex < OrderDataGridView.Rows.Count)
            {
                // 선택한 행의 첫 번째 열 값을 가져오기
                object selectedOrderIdObject = OrderDataGridView.Rows[e.RowIndex].Cells[0].Value;

                // 선택한 주문 ID가 null이 아닌지 확인
                if (selectedOrderIdObject != null)
                {
                    SelectedOrderId = selectedOrderIdObject.ToString();

                    // orderId에 선택된 주문 ID 설정
                    orderId = SelectedOrderId;
                    SelcetOrderTxt.Text = $"{SelectedOrderId}";
                }
                else
                {
                    // 선택한 행의 첫 번째 열이 null인 경우에 대한 처리
                    MessageBox.Show("선택한 주문 ID가 없습니다.");
                }
            }
        }

        // 선택한 주문을 픽업 하는 기능
        private void PickUpBtn_Click(object sender, EventArgs e)
        {
            // 선택한 주문 번호 가져오기
            string selectedOrderId = SelcetOrderTxt.Text;

            // 선택한 주문 번호가 없으면 메시지 출력
            if (string.IsNullOrEmpty(selectedOrderId))
            {
                MessageBox.Show("주문을 먼저 선택하세요.");
                return;
            }

            // 확인 여부 다이얼로그 표시
            DialogResult result = MessageBox.Show("해당 주문을 픽업 하시겠습니까?", "확인", MessageBoxButtons.YesNo);

            // 사용자가 확인을 선택한 경우
            if (result == DialogResult.Yes)
            {
                // 데이터베이스 업데이트
                UpdateOrderStatus(selectedOrderId, "배달중");

                // DriverOrders에 새로운 레코드 추가
                InsertIntoDriverOrders(LoggedInDriverId, selectedOrderId, DateTime.Now);

                // 그리드 뷰와 카운터 새로고침
                DisplayUserOrders();
                Orders_header();
                Orders_counter();

                DisplayDriverOrders();
                DriverOrders_header();
                DriverOrders_counter();

                DriverOrdersComplete_counter();
                DisplayDriverOrdersComplete();
                DriverOrdersComplete_header();

                SelcetOrderTxt.Text = null;
            }
            else
            {
                // 사용자가 취소를 선택한 경우
                MessageBox.Show("주문 픽업이 취소되었습니다.");
            }
        }

        // 주문 픽업, 픽업 취소 시 Orders 테이블의 OrderStatus의 값을 변경시키는 기능
        private void UpdateOrderStatus(string orderId, string newStatus)
        {
            try
            {
                // 연결이 이미 열려 있는지 확인
                if (dbClass.DCom.Connection.State != ConnectionState.Open)
                {
                    // 연결이 열려 있지 않으면 연결을 엽니다.
                    dbClass.DCom.Connection.Open();
                }

                // 주문 상태 업데이트 쿼리
                string updateQuery = $"UPDATE Orders SET OrderStatus = '{newStatus}' WHERE orderId = '{orderId}'";
                dbClass.DCom.CommandText = updateQuery;
                dbClass.DCom.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"주문 상태 업데이트 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
            finally
            {
                // 데이터베이스 연결 닫기
                dbClass.DCom.Connection.Close();
            }
        }

        // 픽업 시 DriverOrders 테이블에 배달번호 픽업 한 주문 번호 픽업을 시작한 시간을 저장
        private void InsertIntoDriverOrders(string driverId, string orderId, DateTime orderStartDate)
        {
            try
            {
                // 데이터베이스 연결 열기
                dbClass.DCom.Connection.Open();

                // DriverOrders에 새로운 레코드 추가 쿼리
                string insertQuery = $"INSERT INTO DriverOrders (dOrderId, driverId, orderId, orderStartDate) " +
                                     $"VALUES (dOrderId_sequence.NEXTVAL, '{driverId}', '{orderId}', TO_TIMESTAMP('{orderStartDate.ToString("yyyy-MM-dd HH:mm:ss")}', 'YYYY-MM-DD HH24:MI:SS'))";
                dbClass.DCom.CommandText = insertQuery;
                dbClass.DCom.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"DriverOrders 레코드 추가 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
            finally
            {
                // 데이터베이스 연결 닫기
                dbClass.DCom.Connection.Close();
            }
        }

        // 배달 기록 셀 클릭 이벤트
        private void DriverOrdersDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < DriverOrdersDataGridView.Rows.Count)
            {
                // 선택한 행의 첫 번째 열 값을 가져와서 텍스트 박스에 표시
                var cellValue = DriverOrdersDataGridView.Rows[e.RowIndex].Cells[0].Value;
                if (cellValue != null)
                {
                    string selectedId = DriverOrdersDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
                    DriverOrdertxt.Text = selectedId;
                }
            }
        }

        // 배달 기록에서 선택한 배달의 주문 픽업을 취소
        private void PickUpCancleBtn_Click(object sender, EventArgs e)
        {
            // 선택한 배달 번호 가져오기
            string selectedDeliveryOrderId = DriverOrdertxt.Text;

            // 선택한 배달 번호가 없으면 메시지 출력
            if (string.IsNullOrEmpty(selectedDeliveryOrderId))
            {
                MessageBox.Show("배달을 먼저 선택하세요.");
                return;
            }

            // 확인 여부 다이얼로그 표시
            DialogResult result = MessageBox.Show("해당 배달을 취소 하시겠습니까?", "확인", MessageBoxButtons.YesNo);

            // 사용자가 확인을 선택한 경우
            if (result == DialogResult.Yes)
            {
                // 배달이 취소되었으므로 해당 배달의 주문 번호 가져오기
                string selectedOrderId = GetOrderIdByDeliveryOrderId(selectedDeliveryOrderId);

                // 주문 상태 업데이트
                UpdateOrderStatus(selectedOrderId, "배달준비");

                // DriverOrders 테이블에서 해당 배달 삭제
                DeleteFromDriverOrders(selectedDeliveryOrderId);

                // 그리드 뷰와 카운터 새로고침
                DisplayUserOrders();
                Orders_header();
                Orders_counter();

                DisplayDriverOrders();
                DriverOrders_header();
                DriverOrders_counter();

                DriverOrdersComplete_counter();
                DisplayDriverOrdersComplete();
                DriverOrdersComplete_header();

                DriverOrdertxt.Text = null;
            }
            else
            {
                // 사용자가 취소를 선택한 경우
                MessageBox.Show("배달 취소가 취소되었습니다.");
            }
        }

        // 주문 번호 가져오기 배달번호(dOrderId)의 값을 가지고 DriverOrders테이블의 orderId 값을 찾는 기능
        private string GetOrderIdByDeliveryOrderId(string deliveryOrderId)
        {
            string orderId = string.Empty;

            try
            {
                // 연결이 이미 열려 있는지 확인
                if (dbClass.DCom.Connection.State != ConnectionState.Open)
                {
                    // 연결이 열려 있지 않으면 연결을 엽니다.
                    dbClass.DCom.Connection.Open();
                }

                // DriverOrders 테이블에서 주문 번호 가져오기
                string query = $"SELECT orderId FROM DriverOrders WHERE dOrderId = '{deliveryOrderId}'";
                dbClass.DCom.CommandText = query;

                orderId = dbClass.DCom.ExecuteScalar()?.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"주문 번호 가져오기 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
            finally
            {
                // 데이터베이스 연결 닫기
                dbClass.DCom.Connection.Close();
            }

            return orderId;
        }

        // DriverOrders 테이블에서 해당 배달 삭제 메서드
        private void DeleteFromDriverOrders(string deliveryOrderId)
        {
            try
            {
                // 연결이 이미 열려 있는지 확인
                if (dbClass.DCom.Connection.State != ConnectionState.Open)
                {
                    // 연결이 열려 있지 않으면 연결을 엽니다.
                    dbClass.DCom.Connection.Open();
                }

                // DriverOrders 테이블에서 해당 배달 삭제 쿼리
                string deleteQuery = $"DELETE FROM DriverOrders WHERE dOrderId = '{deliveryOrderId}'";
                dbClass.DCom.CommandText = deleteQuery;
                dbClass.DCom.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"DriverOrders 삭제 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
            finally
            {
                // 데이터베이스 연결 닫기
                dbClass.DCom.Connection.Close();
            }
        }

        // 배달 완료 이벤트
        private void EndBtn_Click(object sender, EventArgs e)
        {
            // 선택한 배달 번호 가져오기
            string selectedDeliveryOrderId = DriverOrdertxt.Text;

            // 선택한 배달 번호가 없으면 메시지 출력
            if (string.IsNullOrEmpty(selectedDeliveryOrderId))
            {
                MessageBox.Show("배달을 먼저 선택하세요.");
                return;
            }

            // MapForm 인스턴스 생성
            using (MapForm mapForm = new MapForm(this))
            {
                // MapForm에 selectedDeliveryOrderId 전달
                mapForm.SetSelectedDeliveryOrderId(selectedDeliveryOrderId);

                // MapForm을 보여줌
                DialogResult result = mapForm.ShowDialog();

                // 사용자가 확인을 선택한 경우에만 배달 완료 처리
                if (result == DialogResult.OK)
                {
                    CompleteDelivery(selectedDeliveryOrderId);
                }
            }
        }

        // 배달 완료 처리 메서드
        private void CompleteDelivery(string selectedDeliveryOrderId)
        {
            // 배달이 완료된 주문 번호 가져오기
            string orderId = GetOrderIdByDeliveryOrderId(selectedDeliveryOrderId);

            // 주문 상태 업데이트
            UpdateOrderStatus(orderId, "배달완료");

            // 배달 완료 시간 업데이트
            UpdateDeliveryEndDate(selectedDeliveryOrderId, DateTime.Now);

            // 그리드 뷰와 카운터 새로고침
            DisplayUserOrders();
            Orders_header();
            Orders_counter();

            DisplayDriverOrders();
            DriverOrders_header();
            DriverOrders_counter();

            DisplayDriverOrdersComplete();
            DriverOrdersComplete_header();
            DriverOrdersComplete_counter();

            // 선택한 주문번호 초기화
            DriverOrdertxt.Text = null;
        }

        // 배달 완료 시간 업데이트 메서드
        private void UpdateDeliveryEndDate(string selectedDeliveryOrderId, DateTime orderEndDate)
        {
            try
            {
                // 데이터베이스 연결 열기
                dbClass.DCom.Connection.Open();

                // 배달 완료 시간 업데이트 쿼리
                string updateQuery = $"UPDATE DriverOrders SET orderEndDate = TO_TIMESTAMP('{orderEndDate.ToString("yyyy-MM-dd HH:mm:ss")}', 'YYYY-MM-DD HH24:MI:SS') WHERE dOrderId = '{selectedDeliveryOrderId}'";
                dbClass.DCom.CommandText = updateQuery;
                dbClass.DCom.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"배달 완료 시간 업데이트 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
                // 콘솔에 오류 메시지 출력
                Console.WriteLine($"배달 완료 시간 업데이트 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
            finally
            {
                // 데이터베이스 연결 닫기
                dbClass.DCom.Connection.Close();
            }
        }

        public void ReceiveDriverOrderLocation(string selectedDeliveryOrderId, string driverOrderLocation)
        {
            try
            {
                // 연결이 이미 열려 있는지 확인
                if (dbClass.DCom.Connection.State != ConnectionState.Open)
                {
                    // 연결이 열려 있지 않으면 연결을 엽니다.
                    dbClass.DCom.Connection.Open();
                }

                // DriverOrders 테이블에서 orderId 가져오기
                string orderIdQuery = $"SELECT orderId FROM DriverOrders WHERE dOrderId = '{selectedDeliveryOrderId}'";
                dbClass.DCom.CommandText = orderIdQuery;
                string orderId = dbClass.DCom.ExecuteScalar()?.ToString();

                if (!string.IsNullOrEmpty(orderId))
                {
                    // Orders 테이블의 DeliveryAddress 업데이트
                    string updateDeliveryAddressQuery = $"UPDATE Orders SET DeliveryAddress = '{driverOrderLocation}' WHERE orderId = '{orderId}'";
                    dbClass.DCom.CommandText = updateDeliveryAddressQuery;
                    dbClass.DCom.ExecuteNonQuery();

                    MessageBox.Show("주문 정보가 업데이트되었습니다.");
                }
                else
                {
                    MessageBox.Show("주문 ID를 찾을 수 없습니다.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"주문 정보 업데이트 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
            finally
            {
                // 데이터베이스 연결 닫기
                dbClass.DCom.Connection.Close();
            }
        }

        // 메인 페이지 배달 기록 기능
        public void DriverOrders_counter()
        {
            int i = DriverOrdersDataGridView.RowCount;
            DriverOrdersCounter.Text = $"픽업한 주문 : {i} 개";
        }

        private void DisplayDriverOrders()
        {
            if (isLoggedIn)
            {
                // 추가: DriverOrders 테이블을 사용하여 로그인한 배달기사의 주문 목록을 가져오는 쿼리
                string driverOrdersQuery = $"SELECT dOrderId, orderId, orderStartDate FROM DriverOrders WHERE driverId = '{loggedInDriverId}' AND orderEndDate IS NULL";
                dbClass.DCom.CommandText = driverOrdersQuery;

                try
                {
                    // DriverOrders 테이블을 지우고, 주문 목록을 다시 채움
                    if (dbClass.DS.Tables["DriverOrders"] != null)
                    {
                        dbClass.DS.Tables["DriverOrders"].Clear(); // 중복 데이터 제거
                    }

                    dbClass.DA.SelectCommand = dbClass.DCom;
                    dbClass.DA.Fill(dbClass.DS, "DriverOrders");

                    // DataGridView에 주문 목록 표시
                    DriverOrdersDataGridView.DataSource = dbClass.DS.Tables["DriverOrders"].DefaultView;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"운전자 주문 목록 표시 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
                }
            }
        }

        public void DriverOrders_header()
        {
            // Orders 테이블의 열 헤더 설정
            DriverOrdersDataGridView.Columns[0].HeaderText = "배달번호";
            DriverOrdersDataGridView.Columns[1].HeaderText = "주문번호";
            DriverOrdersDataGridView.Columns[2].HeaderText = "배달시작 시간";

            // 각 열의 너비 설정
            DriverOrdersDataGridView.Columns[0].Width = 100;
            DriverOrdersDataGridView.Columns[1].Width = 100;
            DriverOrdersDataGridView.Columns[2].Width = 260;
        }

        // 마이페이지 배달 기록
        // 배달 완료 그리드 뷰의 행 개수를 세는 카운터
        public void DriverOrdersComplete_counter()
        {
            int i = DriverOrdersCompleteDataGridView.RowCount;
            DriverOrdersCompleteCounter.Text = $"배달 완료한 주문 : {i} 개";
        }

        // 배달 완료 그리드 뷰의 헤더와 데이터를 표시하는 메서드
        private void DisplayDriverOrdersComplete()
        {
            if (isLoggedIn)
            {
                // DriverOrders 테이블을 사용하여 로그인한 배달기사의 완료된 주문 목록을 가져오는 쿼리
                string driverOrdersCompleteQuery = $"SELECT dOrderId, orderId, orderStartDate, orderEndDate FROM DriverOrders WHERE driverId = '{loggedInDriverId}' AND orderEndDate IS NOT NULL";
                dbClass.DCom.CommandText = driverOrdersCompleteQuery;

                try
                {
                    // DriverOrders 테이블을 지우고, 주문 목록을 다시 채움
                    if (dbClass.DS.Tables["DriverOrdersComplete"] != null)
                    {
                        dbClass.DS.Tables["DriverOrdersComplete"].Clear(); // 중복 데이터 제거
                    }

                    dbClass.DA.SelectCommand = dbClass.DCom;
                    dbClass.DA.Fill(dbClass.DS, "DriverOrdersComplete");

                    // DataGridView에 주문 목록 표시
                    DriverOrdersCompleteDataGridView.DataSource = dbClass.DS.Tables["DriverOrdersComplete"].DefaultView;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"운전자 완료된 주문 목록 표시 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
                }
            }
        }

        // 배달 완료 그리드 뷰의 헤더 설정
        public void DriverOrdersComplete_header()
        {
            // Orders 테이블의 열 헤더 설정
            DriverOrdersCompleteDataGridView.Columns[0].HeaderText = "배달번호";
            DriverOrdersCompleteDataGridView.Columns[1].HeaderText = "주문번호";
            DriverOrdersCompleteDataGridView.Columns[2].HeaderText = "배달시작 시간";
            DriverOrdersCompleteDataGridView.Columns[3].HeaderText = "배달완료 시간";

            // 각 열의 너비 설정
            DriverOrdersCompleteDataGridView.Columns[0].Width = 100;
            DriverOrdersCompleteDataGridView.Columns[1].Width = 100;
            DriverOrdersCompleteDataGridView.Columns[2].Width = 130;
            DriverOrdersCompleteDataGridView.Columns[3].Width = 130;
        }



        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            DriverUpdateForm driverUpdateForm = new DriverUpdateForm(loggedInDriverId);
            driverUpdateForm.Show();
        }

        private void SignOutBtn_Click(object sender, EventArgs e)
        {
            SignOutForm signOutForm = new SignOutForm(loggedInDriverId);

            // 추가: SignOutForm의 LoggedOut 이벤트 핸들러 등록
            signOutForm.LoggedOut += (s, args) =>
            {
                loggedInTextBox.Visible = false;
                logoutButton.Visible = false;

                LoginBtn.Visible = true;
                SignUpBtn.Visible = true;

                OrderDataGridView.DataSource = null;
                Orders_counter();

                DriverOrdersDataGridView.DataSource = null;
                DriverOrders_counter();

                DriverIdTxt.Text = null;
                DriverOrdersCompleteDataGridView.DataSource = null;
                DriverOrdersComplete_counter();

                // 로그인 상태 갱신
                isLoggedIn = false;
            };

            signOutForm.Show();
        }


        private void 주문위치조회ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // 선택한 주문의 주문번호 가져오기
            if (!string.IsNullOrEmpty(SelectedOrderId))
            {
                // 주문번호로 DeliveryAddress 값 가져오기
                string deliveryAddress = "";

                try
                {
                    // Orders 테이블에서 DeliveryAddress 값 가져오기
                    string selectLocationQuery = $"SELECT DeliveryAddress FROM Orders WHERE orderId = '{SelectedOrderId}'";
                    dbClass.DCom.CommandText = selectLocationQuery;

                    if (dbClass.DCom.Connection.State == ConnectionState.Closed)
                        dbClass.DCom.Connection.Open();

                    using (var reader = dbClass.DCom.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            deliveryAddress = reader["DeliveryAddress"].ToString();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"DeliveryAddress 값 불러오기 오류: {ex.Message}");
                    return;
                }
                finally
                {
                    dbClass.DisconnectFromDatabase();
                }

                // DeliveryAddress 값이 유효한 경우 MapForm 열기
                if (!string.IsNullOrEmpty(deliveryAddress))
                {
                    // 새로운 MapForm 열기
                    MapForm mapForm = new MapForm(this);
                    mapForm.SetLocationAndSearch(deliveryAddress); // MapForm에 DeliveryAddress 설정 및 검색
                    mapForm.ShowDialog();
                }
                else
                {
                    MessageBox.Show("DeliveryAddress 값이 없습니다.");
                }
            }
            else
            {
                MessageBox.Show("주문을 선택해주세요.");
            }
        }

        private void 픽업주문위치조회ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // 선택한 배달 기록의 dOrderId 가져오기
            if (!string.IsNullOrEmpty(DriverOrdertxt.Text))
            {
                string selectedDeliveryOrderId = DriverOrdertxt.Text;

                try
                {
                    // 데이터베이스 연결이 닫혀 있는 경우 연결 열기
                    if (dbClass.DCom.Connection.State == ConnectionState.Closed)
                    {
                        dbClass.DCom.Connection.Open();
                    }

                    // Orders 테이블과 DriverOrders 테이블을 조인하여 DeliveryAddress 값을 가져오기
                    string selectDeliveryAddressQuery = $"SELECT o.DeliveryAddress FROM DriverOrders do JOIN Orders o ON do.orderId = o.orderId WHERE do.dOrderId = '{selectedDeliveryOrderId}'";
                    dbClass.DCom.CommandText = selectDeliveryAddressQuery;

                    // 쿼리 실행
                    using (var reader = dbClass.DCom.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // DeliveryAddress 값이 존재하면 지도에 표시
                            string deliveryAddress = reader["DeliveryAddress"].ToString();

                            if (!string.IsNullOrEmpty(deliveryAddress))
                            {
                                // 새로운 MapForm 열기
                                MapForm mapForm = new MapForm(this);
                                mapForm.SetLocationAndSearch(deliveryAddress); // MapForm에 DeliveryAddress 설정 및 검색
                                mapForm.ShowDialog();
                            }
                            else
                            {
                                MessageBox.Show("DeliveryAddress 값이 없습니다.");
                            }
                        }
                        else
                        {
                            MessageBox.Show("해당 주문에 대한 정보를 찾을 수 없습니다.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"DeliveryAddress 값 불러오기 오류: {ex.Message}");
                }
                finally
                {
                    // 데이터베이스 연결 닫기
                    if (dbClass.DCom.Connection.State == ConnectionState.Open)
                    {
                        dbClass.DCom.Connection.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("배달 기록을 선택해주세요.");
            }
        }
    }
}