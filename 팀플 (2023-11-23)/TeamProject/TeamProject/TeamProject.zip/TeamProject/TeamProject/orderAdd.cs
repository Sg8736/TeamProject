﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeamProject
{
    public partial class orderAdd : Form
    {
        private string productId;
        private decimal productPrice;

        public orderAdd(string productId)
        {
            InitializeComponent();
            this.productId = productId;
            this.productPrice = productPrice;
            // 필요한 경우 productId를 사용하여 초기 데이터 설정
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            // 유효성 검사
            // 예: if (string.IsNullOrEmpty(txtUserId.Text) || string.IsNullOrEmpty(txtQuantity.Text) ...)

            // 수량을 가져옵니다
            int quantity = Convert.ToInt32(textBox4.Text);

            //금액을 계산합니다
            decimal totalAmount = quantity * productPrice;

            // 데이터베이스에 장바구니 데이터 추가
            // 예: InsertIntoCartDatabase(productId, txtUserId.Text, ...);

            // 결과 메시지 표시
            MessageBox.Show("해당 제품에 대한 총 금액은: " + totalAmount + "원 입니다.");
            this.Close();
        }

        // 데이터베이스에 장바구니 데이터를 추가하는 메서드 (가상 구현)
        private void InsertIntoCartDatabase(string productId, string userId)
        {
            // 데이터베이스 연결 및 INSERT 쿼리 실행
        }
    }
}
