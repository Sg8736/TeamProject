﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;

namespace TeamProject
{
    public partial class AdminForm : Form
    {
        private DBClass dbClass;

        public AdminForm()
        {
            InitializeComponent();
            dbClass = new DBClass();

        }

        private void AdminForm_Load(object sender, EventArgs e)
        {
            // DB 연결
            if (dbClass.ConnectToDatabase())
            {
                // USERINFO 테이블을 userDataGridView에 표시
                DisplayUserInfoTable();

                // USERINFO 테이블의 열 헤더 설정
                USERINFO_header();

                // Inquiries 테이블을 inqDataGridView에 표시
                DisplayInquiriesTable();

                // Inquiries 테이블의 열 헤더 설정
                Inquiries_header();

                // DriverInfo 테이블을 driverDataGridView에 표시
                DisplayDriverInfoTable();

                // DriverInfo 테이블의 열 헤더 설정
                DriverInfo_header();

                // inqDataGridView의 CellClick 이벤트 핸들러 등록
                inqDataGridView.CellClick += inqDataGridView_CellClick;
            }
            else
            {
                MessageBox.Show("DB 연결에 실패했습니다.");
                this.Close();
            }
            USERINFO_counter();
            Orders_counter();
            Inquiries_counter();
            DriverInfo_counter();
            DOrders_counter();
        }
               

        // 배달기사 관련 기능
        public void DriverInfo_counter()
        {
            int i;
            i = driverDataGridView.RowCount;
            driverCounter.Text = "총 " + i + "명";
        }

        private void DisplayDriverInfoTable(){
            // DriverInfo 테이블을 driverDataGridView에 표시
            string sqlstr = "SELECT driverId, dName, dPhone FROM DriverInfo ORDER BY driverId ASC";
            dbClass.DCom.CommandText = sqlstr;

            // DriverInfo 테이블에 데이터를 채움
            if (dbClass.DS.Tables["DriverInfo"] != null)
            {
                dbClass.DS.Tables["DriverInfo"].Clear(); // 중복 데이터 제거
            }
            dbClass.DA.SelectCommand = dbClass.DCom;
            dbClass.DA.Fill(dbClass.DS, "DriverInfo");

            // driverDataGridView에 데이터 소스 설정
            driverDataGridView.DataSource = dbClass.DS.Tables["DriverInfo"].DefaultView;
        }
        private void DriverInfo_header()
        {
            // DriverInfo 테이블의 열 헤더 설정
            driverDataGridView.Columns[0].HeaderText = "ID";
            driverDataGridView.Columns[1].HeaderText = "이름";
            driverDataGridView.Columns[2].HeaderText = "전화번호";            
            // 각 열의 너비 설정
            driverDataGridView.Columns[0].Width = 70;
            driverDataGridView.Columns[1].Width = 60;
            driverDataGridView.Columns[2].Width = 150;
            
        }

        private void driverDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < driverDataGridView.Rows.Count)
            {
                // 선택한 행의 첫 번째 열 값을 가져와서 텍스트 박스에 표시
                string selectedId = driverDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
                driverIdTxt.Text = selectedId;
            }
        }

        private void dSearchBtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(driverIdTxt.Text))
            {
                // 선택한 ID에 해당하는 배달 기록을 가져와서 표시
                DisplayDOrdersTable(driverIdTxt.Text);

                // dOrders_counter 호출하여 배달 기록 갱신
                DOrders_counter();
            }
        }

        // 배달 기록 기능
        public void DOrders_counter()
        {
            int i;
            i = dOrderDataGridView.RowCount;
            dOrderCounter.Text = "총 " + i + "개";
        }

        private void DisplayDOrdersTable(String orderId)
        {
            // DOrders 테이블이 없으면 생성
            if (dbClass.DS.Tables["DOrders"] == null)
            {
                dbClass.DS.Tables.Add("DOrders");
            }

            // DOrders 테이블을 사용하여 주문 목록을 가져오는 쿼리
            string sqlstr = $"SELECT dOrderId, orderId, orderStartDate, orderEndDate FROM DOrders WHERE orderId = '{orderId}'";
            dbClass.DCom.CommandText = sqlstr;

            try
            {
                // DOrders 테이블을 지우고, 주문 목록을 다시 채움
                dbClass.DS.Tables["DOrders"].Clear();
                dbClass.DA.SelectCommand = dbClass.DCom;
                dbClass.DA.Fill(dbClass.DS, "DOrders");

                // DataGridView에 주문 목록 표시
                dOrderDataGridView.DataSource = dbClass.DS.Tables["DOrders"].DefaultView;

                // DOrders 테이블의 열 헤더 설정
                DOrders_header();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"배달 기록 표시 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
        }

        private void DOrders_header()
        {
            // DriverInfo 테이블의 열 헤더 설정
            dOrderDataGridView.Columns[0].HeaderText = "배달번호";
            dOrderDataGridView.Columns[1].HeaderText = "주문번호";
            dOrderDataGridView.Columns[2].HeaderText = "배달시작 시간";
            dOrderDataGridView.Columns[3].HeaderText = "배달종료 시간";
            // 각 열의 너비 설정
            dOrderDataGridView.Columns[0].Width = 80;
            dOrderDataGridView.Columns[1].Width = 80;
            dOrderDataGridView.Columns[2].Width = 150;
            dOrderDataGridView.Columns[3].Width = 150;
        }


        // 고객 데이터 기능
        public void USERINFO_counter()
        {
            int i;
            i = userDataGridView.RowCount;
            userCounter.Text = "총 " + i + " 명";
        }

        private void DisplayUserInfoTable()
        {
            // USERINFO 테이블을 DataGridView에 표시
            string sqlstr = "SELECT userId, name, phone, address, SignUpDate FROM USERINFO ORDER BY userId ASC";
            dbClass.DCom.CommandText = sqlstr;

            // USERINFO 테이블에 데이터를 채움
            dbClass.DS.Tables["USERINFO"].Clear(); // 중복 데이터 제거
            dbClass.DA.SelectCommand = dbClass.DCom;
            dbClass.DA.Fill(dbClass.DS, "USERINFO");

            // DataGridView에 데이터 소스 설정
            userDataGridView.DataSource = dbClass.DS.Tables["USERINFO"].DefaultView;
        }

        private void USERINFO_header()
        {
            // USERINFO 테이블의 열 헤더 설정
            userDataGridView.Columns[0].HeaderText = "ID";
            userDataGridView.Columns[1].HeaderText = "이름";
            userDataGridView.Columns[2].HeaderText = "전화번호";
            userDataGridView.Columns[3].HeaderText = "주소";
            userDataGridView.Columns[4].HeaderText = "가입 날짜"; // 수정된 부분

            // 각 열의 너비 설정
            userDataGridView.Columns[0].Width = 70;
            userDataGridView.Columns[1].Width = 60;
            userDataGridView.Columns[2].Width = 90;
            userDataGridView.Columns[3].Width = 150;
            userDataGridView.Columns[4].Width = 90;
        }

        private void userDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < userDataGridView.Rows.Count)
            {
                // 선택한 행의 첫 번째 열 값을 가져와서 텍스트 박스에 표시
                string selectedId = userDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
                userIdTxt.Text = selectedId;
            }
        }

        private void SearchBtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(userIdTxt.Text))
            {
                // 선택한 ID에 해당하는 주문 목록을 가져와서 표시
                DisplayUserOrders(userIdTxt.Text);

                // Orders_counter 호출하여 주문 횟수 갱신
                Orders_counter();
            }
        }

        // 고객 계정 삭제 기능
        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            // 사용자가 선택한지 확인
            if (!string.IsNullOrEmpty(userIdTxt.Text))
            {
                // 사용자에게 삭제 여부 확인
                DialogResult result = MessageBox.Show("해당 고객의 계정을 삭제하시겠습니까?", "계정 삭제 확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    string userIdToDelete = userIdTxt.Text;

                    // Inquiries, Orders, USERINFO 테이블에서 레코드 삭제
                    DeleteInquiries(userIdToDelete);
                    DeleteOrders(userIdToDelete);
                    DeleteUserInfo(userIdToDelete);

                    // DataGridView 새로고침
                    DisplayUserInfoTable();
                    DisplayUserOrders(userIdToDelete);
                    DisplayInquiriesTable();

                    // 카운터 업데이트
                    USERINFO_counter();
                    Orders_counter();
                    Inquiries_counter();
                }
            }
            else
            {
                MessageBox.Show("삭제할 유저를 선택하세요.");
            }
        }

        // Inquiries 테이블 삭제 기능
        private void DeleteInquiries(string userId)
        {
            // Inquiries 테이블에서 해당 유저의 레코드 삭제
            string deleteInquiriesSql = $"DELETE FROM Inquiries WHERE userId = '{userId}'";
            dbClass.DCom.CommandText = deleteInquiriesSql;
            dbClass.DCom.ExecuteNonQuery();
        }

        // Orders 테이블 삭제 기능
        private void DeleteOrders(string userId)
        {
            // Orders 테이블에서 해당 유저의 레코드 삭제
            string deleteOrdersSql = $"DELETE FROM Orders WHERE userId = '{userId}'";
            dbClass.DCom.CommandText = deleteOrdersSql;
            dbClass.DCom.ExecuteNonQuery();
        }

        // UserInfo 테이블 삭제 기능
        private void DeleteUserInfo(string userId)
        {
            // USERINFO 테이블에서 해당 유저의 레코드 삭제
            string deleteUserInfoSql = $"DELETE FROM USERINFO WHERE userId = '{userId}'";
            dbClass.DCom.CommandText = deleteUserInfoSql;
            dbClass.DCom.ExecuteNonQuery();
        }

        // 주문 관련 기능
        public void Orders_counter()
        {
            int i = orderDataGridView.RowCount;
            orderCounter.Text = $"주문횟수: {i} 번";
        }

        private void DisplayUserOrders(string userId)
        {
            // ORDERS 테이블이 없으면 생성
            if (dbClass.DS.Tables["Orders"] == null)
            {
                dbClass.DS.Tables.Add("Orders");
            }

            // Orders 테이블을 사용하여 주문 목록을 가져오는 쿼리
            string sqlstr = $"SELECT * FROM Orders WHERE userId = '{userId}'";
            dbClass.DCom.CommandText = sqlstr;

            try
            {
                // ORDERS 테이블을 지우고, 주문 목록을 다시 채움
                dbClass.DS.Tables["Orders"].Clear();
                dbClass.DA.SelectCommand = dbClass.DCom;
                dbClass.DA.Fill(dbClass.DS, "Orders");

                // DataGridView에 주문 목록 표시
                orderDataGridView.DataSource = dbClass.DS.Tables["Orders"].DefaultView;

                // Orders 테이블의 열 헤더 설정
                Orders_header();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"주문 목록 표시 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
        }

        public void Orders_header()
        {
            // Orders 테이블의 열 헤더 설정
            orderDataGridView.Columns[0].HeaderText = "주문번호";
            orderDataGridView.Columns[1].HeaderText = "주소";
            orderDataGridView.Columns[2].HeaderText = "주문상태";
            orderDataGridView.Columns[3].HeaderText = "총액";
            orderDataGridView.Columns[4].HeaderText = "ID";

            // 각 열의 너비 설정
            orderDataGridView.Columns[0].Width = 80;
            orderDataGridView.Columns[1].Width = 150;
            orderDataGridView.Columns[2].Width = 90;
            orderDataGridView.Columns[3].Width = 70;
            orderDataGridView.Columns[4].Width = 70;
        }


        private void AdminForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            // 폼이 닫힐 때 DB 연결 해제
            dbClass.DisconnectFromDatabase();
        }

        // 고객 문의 관련 기능
        public void Inquiries_counter()
        {
            int i;
            i = inqDataGridView.RowCount;
            inqCounter.Text = "총 " + i + " 개";
        }

        private void DisplayInquiriesTable()
        {
            // Inquiries 테이블을 DataGridView에 표시
            string sqlstr = "SELECT inqId, orderId, userId, title, createDate, hasReply FROM Inquiries ORDER BY inqId ASC";
            dbClass.DCom.CommandText = sqlstr;

            // Inquiries 테이블에 데이터를 채움
            dbClass.DS.Tables["Inquiries"].Clear(); // 중복 데이터 제거
            dbClass.DA.SelectCommand = dbClass.DCom;
            dbClass.DA.Fill(dbClass.DS, "Inquiries");

            // DataGridView에 데이터 소스 설정
            inqDataGridView.DataSource = dbClass.DS.Tables["Inquiries"].DefaultView;
        }
        public void RefreshInquiriesTable()
        {
            DisplayInquiriesTable();
        }
        private void Inquiries_header()
        {
            // Inquiries 테이블의 열 헤더 설정
            inqDataGridView.Columns[0].HeaderText = "번호";
            inqDataGridView.Columns[1].HeaderText = "주문번호";
            inqDataGridView.Columns[2].HeaderText = "아이디";
            inqDataGridView.Columns[3].HeaderText = "제목";
            inqDataGridView.Columns[4].HeaderText = "작성일자";
            inqDataGridView.Columns[5].HeaderText = "답글 여부";

            // 각 열의 너비 설정
            inqDataGridView.Columns[0].Width = 80;
            inqDataGridView.Columns[1].Width = 80;
            inqDataGridView.Columns[2].Width = 80;
            inqDataGridView.Columns[3].Width = 80;
            inqDataGridView.Columns[4].Width = 80;
            inqDataGridView.Columns[5].Width = 80;
        }

        private void inqDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < inqDataGridView.Rows.Count)
            {
                // 선택한 행의 첫 번째 열 값을 가져와서 텍스트 박스에 표시
                var cellValue = inqDataGridView.Rows[e.RowIndex].Cells[0].Value;
                if (cellValue != null)
                {
                    string selectedId = inqDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
                    InqNumTxt.Text = selectedId;
                }
            }
        }

        private void ReplyBtn_Click(object sender, EventArgs e)
        {
            // 선택한 행의 inqId 값을 가져오기
            if (!string.IsNullOrEmpty(InqNumTxt.Text) && int.TryParse(InqNumTxt.Text, out int inqId))
            {
                // inqId에 해당하는 Inquiries 테이블의 정보 가져오기
                string sqlstr = $"SELECT userId, orderId, title, content FROM Inquiries WHERE inqId = {inqId}";
                dbClass.DCom.CommandText = sqlstr;

                try
                {
                    // DataTable이 없으면 생성
                    if (dbClass.DS.Tables["InquiryDetails"] == null)
                    {
                        dbClass.DS.Tables.Add("InquiryDetails");
                    }

                    dbClass.DS.Tables["InquiryDetails"].Clear();
                    dbClass.DA.SelectCommand = dbClass.DCom;
                    dbClass.DA.Fill(dbClass.DS, "InquiryDetails");

                    // DataTable에서 해당 정보 가져오기
                    string userId = dbClass.DS.Tables["InquiryDetails"].Rows[0]["userId"].ToString();
                    string orderId = dbClass.DS.Tables["InquiryDetails"].Rows[0]["orderId"].ToString();
                    string title = dbClass.DS.Tables["InquiryDetails"].Rows[0]["title"].ToString();
                    string content = dbClass.DS.Tables["InquiryDetails"].Rows[0]["content"].ToString();

                    // InquiryAdminForm 열기
                    InquiryAdminForm inquiryAdminForm = new InquiryAdminForm(inqId, userId, orderId, title, content, this);
                    inquiryAdminForm.ShowDialog();

                    // 고객 문의 테이블 새로고침
                    DisplayInquiriesTable();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"문의 정보 불러오기 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
                }
            }
            else
            {
                MessageBox.Show("문의를 선택해주세요.");
            }
        }

        private void CkReplyBtn_Click(object sender, EventArgs e)
        {
            // 선택한 행의 inqId 값을 가져오기
            if (!string.IsNullOrEmpty(InqNumTxt.Text) && int.TryParse(InqNumTxt.Text, out int inqId))
            {
                // inqId에 해당하는 Inquiries 테이블의 정보 가져오기
                string sqlstr = $"SELECT userId, orderId, title, content, reply FROM Inquiries WHERE inqId = {inqId}";
                dbClass.DCom.CommandText = sqlstr;

                try
                {
                    // DataTable이 없으면 생성
                    if (dbClass.DS.Tables["InquiryDetails"] == null)
                    {
                        dbClass.DS.Tables.Add("InquiryDetails");
                    }

                    dbClass.DS.Tables["InquiryDetails"].Clear();
                    dbClass.DA.SelectCommand = dbClass.DCom;
                    dbClass.DA.Fill(dbClass.DS, "InquiryDetails");

                    // DataTable에서 해당 정보 가져오기
                    string userId = dbClass.DS.Tables["InquiryDetails"].Rows[0]["userId"].ToString();
                    string orderId = dbClass.DS.Tables["InquiryDetails"].Rows[0]["orderId"].ToString();
                    string title = dbClass.DS.Tables["InquiryDetails"].Rows[0]["title"].ToString();
                    string content = dbClass.DS.Tables["InquiryDetails"].Rows[0]["content"].ToString();
                    string reply = dbClass.DS.Tables["InquiryDetails"].Rows[0]["reply"].ToString();

                    // InquiryAdminForm 열기
                    InquiryAdminForm inquiryAdminForm = new InquiryAdminForm(inqId, userId, orderId, title, content, reply, this);
                    inquiryAdminForm.ShowDialog();

                    // 고객 문의 테이블 새로고침
                    DisplayInquiriesTable();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"문의 정보 불러오기 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
                }
            }
            else
            {
                MessageBox.Show("문의를 선택해주세요.");
            }
        }
    }
}