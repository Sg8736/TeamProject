﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;


namespace TeamProject
{
    public partial class UserUpdateForm : Form
    {
        private DBClass dbClass;
        private string LoggedInUserId;

        public UserUpdateForm(string loggedInUserId)
        {
            InitializeComponent();
            dbClass = new DBClass();

            // 생성자에서 userId 초기화
            LoggedInUserId = loggedInUserId;
            // 해당 ID를 텍스트 박스에 표시
            txtid.Text = LoggedInUserId;
            // 텍스트 박스를 읽기 전용으로 설정
            txtid.ReadOnly = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dbClass.ConnectToDatabase())
            {
                try
                {
                    string phone = $"{txtphone1.Text}-{txtphone2.Text}-{txtphone3.Text}";
                    string emailDomain = lstEmailDomains.SelectedItem?.ToString();

                    // 이메일 도메인이 선택되지 않았거나 빈 경우에 대한 처리
                    if (string.IsNullOrWhiteSpace(emailDomain))
                    {
                        MessageBox.Show("이메일 도메인을 선택하세요.", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    string email = $"{txtemail.Text}@{emailDomain}";

                    // 중복 체크 메서드 수정
                    string duplicateInfo = dbClass.CheckDuplicateUserInfoForUpdate(LoggedInUserId, phone, email);

                    if (duplicateInfo != null)
                    {
                        MessageBox.Show(duplicateInfo, "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        // 수정 처리
                        if (dbClass.UpdateUser(LoggedInUserId, txtpwd.Text, txtname.Text, txtaddress.Text, phone, email))
                        {
                            MessageBox.Show("수정 완료");
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("수정 실패");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    // 연결 안전하게 해제
                    dbClass.DisconnectFromDatabase();
                }
            }
        }
    }
}