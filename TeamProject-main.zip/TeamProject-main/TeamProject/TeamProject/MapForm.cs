﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeamProject
{
    public partial class MapForm : Form
    {
        public MapForm()
        {
            InitializeComponent();
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                //엔터를 누르면 버튼을 누른다는 뜻
                button1.PerformClick();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<Locale> locales = KakaoApi.Search(textBox1.Text);
            listBox1.Items.Clear();
            foreach (Locale locale in locales)
            {
                listBox1.Items.Add(locale);
            }
        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1)
                return;
            Locale ml = listBox1.SelectedItem as Locale;
            object[] pos = new object[] { ml.Lat, ml.Lng };
            HtmlDocument hdoc = webBrowser1.Document;
            hdoc.InvokeScript("setCenter", pos);
        }

        public void SetLocationAndSearch(string location)
        {
            textBox1.Text = location;

            List<Locale> locales = KakaoApi.Search(textBox1.Text);
            listBox1.Items.Clear();
            foreach (Locale locale in locales)
            {
                listBox1.Items.Add(locale);
            }

            if (locales.Count > 0)
            {
                // 리스트 박스의 첫 번째 아이템을 선택하도록 설정
                listBox1.SelectedIndex = 0;

                // 선택한 아이템에 해당하는 위치로 지도 이동
                Locale ml = locales[0]; // 첫 번째 아이템 선택
                object[] pos = new object[] { ml.Lat, ml.Lng };
                HtmlDocument hdoc = webBrowser1.Document;
                hdoc.InvokeScript("setCenter", pos);

                // 리스트 박스의 첫 번째 아이템을 자동으로 클릭 (MouseDown 이벤트를 호출하여 처리)
                //listBox1_MouseDown(listBox1, new MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0));

                listBox1_SelectedIndexChanged(listBox1, EventArgs.Empty);
            }
        }

    }
}
