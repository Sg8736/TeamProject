﻿
namespace TeamProject
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.userDataGridView = new System.Windows.Forms.DataGridView();
            this.userCounter = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.orderDataGridView = new System.Windows.Forms.DataGridView();
            this.orderCounter = new System.Windows.Forms.Label();
            this.groupbox2 = new System.Windows.Forms.GroupBox();
            this.userIdTxt = new System.Windows.Forms.TextBox();
            this.SearchBtn = new System.Windows.Forms.Button();
            this.DeleteBtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.driverCounter = new System.Windows.Forms.Label();
            this.driverDataGridView = new System.Windows.Forms.DataGridView();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.dOrderCounter = new System.Windows.Forms.Label();
            this.dOrderDataGridView = new System.Windows.Forms.DataGridView();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dDeleteBtn = new System.Windows.Forms.Button();
            this.dSearchBtn = new System.Windows.Forms.Button();
            this.driverIdTxt = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.CkReplyBtn = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.InqNumTxt = new System.Windows.Forms.TextBox();
            this.ReplyBtn = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.inqCounter = new System.Windows.Forms.Label();
            this.inqDataGridView = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.userDataGridView)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.orderDataGridView)).BeginInit();
            this.groupbox2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.driverDataGridView)).BeginInit();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dOrderDataGridView)).BeginInit();
            this.groupBox10.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inqDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // userDataGridView
            // 
            this.userDataGridView.AllowUserToAddRows = false;
            this.userDataGridView.AllowUserToDeleteRows = false;
            this.userDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.userDataGridView.Location = new System.Drawing.Point(27, 32);
            this.userDataGridView.Name = "userDataGridView";
            this.userDataGridView.ReadOnly = true;
            this.userDataGridView.RowHeadersVisible = false;
            this.userDataGridView.RowTemplate.Height = 23;
            this.userDataGridView.Size = new System.Drawing.Size(457, 199);
            this.userDataGridView.TabIndex = 0;
            this.userDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.userDataGridView_CellClick);
            // 
            // userCounter
            // 
            this.userCounter.AutoSize = true;
            this.userCounter.Location = new System.Drawing.Point(433, 17);
            this.userCounter.Name = "userCounter";
            this.userCounter.Size = new System.Drawing.Size(51, 12);
            this.userCounter.TabIndex = 1;
            this.userCounter.Text = "총 000명";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.userCounter);
            this.groupBox4.Controls.Add(this.userDataGridView);
            this.groupBox4.Location = new System.Drawing.Point(8, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(507, 247);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "고객정보";
            // 
            // orderDataGridView
            // 
            this.orderDataGridView.AllowUserToAddRows = false;
            this.orderDataGridView.AllowUserToDeleteRows = false;
            this.orderDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.orderDataGridView.Location = new System.Drawing.Point(24, 33);
            this.orderDataGridView.Name = "orderDataGridView";
            this.orderDataGridView.ReadOnly = true;
            this.orderDataGridView.RowHeadersVisible = false;
            this.orderDataGridView.RowTemplate.Height = 23;
            this.orderDataGridView.Size = new System.Drawing.Size(460, 198);
            this.orderDataGridView.TabIndex = 1;
            // 
            // orderCounter
            // 
            this.orderCounter.AutoSize = true;
            this.orderCounter.Location = new System.Drawing.Point(389, 17);
            this.orderCounter.Name = "orderCounter";
            this.orderCounter.Size = new System.Drawing.Size(95, 12);
            this.orderCounter.TabIndex = 2;
            this.orderCounter.Text = "주문횟수 : 000번";
            // 
            // groupbox2
            // 
            this.groupbox2.Controls.Add(this.orderCounter);
            this.groupbox2.Controls.Add(this.orderDataGridView);
            this.groupbox2.Location = new System.Drawing.Point(8, 259);
            this.groupbox2.Name = "groupbox2";
            this.groupbox2.Size = new System.Drawing.Size(507, 247);
            this.groupbox2.TabIndex = 6;
            this.groupbox2.TabStop = false;
            this.groupbox2.Text = "주문내역";
            // 
            // userIdTxt
            // 
            this.userIdTxt.Location = new System.Drawing.Point(77, 29);
            this.userIdTxt.Name = "userIdTxt";
            this.userIdTxt.Size = new System.Drawing.Size(100, 21);
            this.userIdTxt.TabIndex = 0;
            // 
            // SearchBtn
            // 
            this.SearchBtn.Location = new System.Drawing.Point(7, 67);
            this.SearchBtn.Name = "SearchBtn";
            this.SearchBtn.Size = new System.Drawing.Size(89, 34);
            this.SearchBtn.TabIndex = 1;
            this.SearchBtn.Text = "주문내역 검색";
            this.SearchBtn.UseVisualStyleBackColor = true;
            this.SearchBtn.Click += new System.EventHandler(this.SearchBtn_Click);
            // 
            // DeleteBtn
            // 
            this.DeleteBtn.Location = new System.Drawing.Point(120, 67);
            this.DeleteBtn.Name = "DeleteBtn";
            this.DeleteBtn.Size = new System.Drawing.Size(89, 34);
            this.DeleteBtn.TabIndex = 3;
            this.DeleteBtn.Text = "고객계정 삭제";
            this.DeleteBtn.UseVisualStyleBackColor = true;
            this.DeleteBtn.Click += new System.EventHandler(this.DeleteBtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 12);
            this.label2.TabIndex = 9;
            this.label2.Text = "고객 ID : ";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.DeleteBtn);
            this.groupBox5.Controls.Add(this.SearchBtn);
            this.groupBox5.Controls.Add(this.userIdTxt);
            this.groupBox5.Location = new System.Drawing.Point(555, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(216, 110);
            this.groupBox5.TabIndex = 8;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "사용자관리";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1104, 555);
            this.tabControl1.TabIndex = 10;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.groupbox2);
            this.tabPage1.Controls.Add(this.groupBox5);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1096, 529);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "고객/주문 관리";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Controls.Add(this.groupBox8);
            this.tabPage2.Controls.Add(this.groupBox10);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1096, 529);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "배달기사 관리";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.driverCounter);
            this.groupBox6.Controls.Add(this.driverDataGridView);
            this.groupBox6.Location = new System.Drawing.Point(242, 3);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(329, 258);
            this.groupBox6.TabIndex = 11;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "배달기사 정보";
            // 
            // driverCounter
            // 
            this.driverCounter.AutoSize = true;
            this.driverCounter.Location = new System.Drawing.Point(259, 17);
            this.driverCounter.Name = "driverCounter";
            this.driverCounter.Size = new System.Drawing.Size(51, 12);
            this.driverCounter.TabIndex = 1;
            this.driverCounter.Text = "총 000명";
            // 
            // driverDataGridView
            // 
            this.driverDataGridView.AllowUserToAddRows = false;
            this.driverDataGridView.AllowUserToDeleteRows = false;
            this.driverDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.driverDataGridView.Location = new System.Drawing.Point(27, 32);
            this.driverDataGridView.Name = "driverDataGridView";
            this.driverDataGridView.ReadOnly = true;
            this.driverDataGridView.RowHeadersVisible = false;
            this.driverDataGridView.RowTemplate.Height = 23;
            this.driverDataGridView.Size = new System.Drawing.Size(283, 210);
            this.driverDataGridView.TabIndex = 0;
            this.driverDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.driverDataGridView_CellClick);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.dOrderCounter);
            this.groupBox8.Controls.Add(this.dOrderDataGridView);
            this.groupBox8.Location = new System.Drawing.Point(577, 8);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(510, 253);
            this.groupBox8.TabIndex = 10;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "배달기록";
            // 
            // dOrderCounter
            // 
            this.dOrderCounter.AutoSize = true;
            this.dOrderCounter.Location = new System.Drawing.Point(399, 17);
            this.dOrderCounter.Name = "dOrderCounter";
            this.dOrderCounter.Size = new System.Drawing.Size(95, 12);
            this.dOrderCounter.TabIndex = 2;
            this.dOrderCounter.Text = "주문횟수 : 000번";
            // 
            // dOrderDataGridView
            // 
            this.dOrderDataGridView.AllowUserToAddRows = false;
            this.dOrderDataGridView.AllowUserToDeleteRows = false;
            this.dOrderDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dOrderDataGridView.Location = new System.Drawing.Point(19, 32);
            this.dOrderDataGridView.Name = "dOrderDataGridView";
            this.dOrderDataGridView.ReadOnly = true;
            this.dOrderDataGridView.RowHeadersVisible = false;
            this.dOrderDataGridView.RowTemplate.Height = 23;
            this.dOrderDataGridView.Size = new System.Drawing.Size(475, 205);
            this.dOrderDataGridView.TabIndex = 1;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label9);
            this.groupBox10.Controls.Add(this.dDeleteBtn);
            this.groupBox10.Controls.Add(this.dSearchBtn);
            this.groupBox10.Controls.Add(this.driverIdTxt);
            this.groupBox10.Location = new System.Drawing.Point(3, 3);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(233, 111);
            this.groupBox10.TabIndex = 13;
            this.groupBox10.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 32);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 12);
            this.label9.TabIndex = 9;
            this.label9.Text = "배달 기사 ID : ";
            // 
            // dDeleteBtn
            // 
            this.dDeleteBtn.Location = new System.Drawing.Point(135, 67);
            this.dDeleteBtn.Name = "dDeleteBtn";
            this.dDeleteBtn.Size = new System.Drawing.Size(89, 34);
            this.dDeleteBtn.TabIndex = 3;
            this.dDeleteBtn.Text = "배달기사 계정 삭제";
            this.dDeleteBtn.UseVisualStyleBackColor = true;
            // 
            // dSearchBtn
            // 
            this.dSearchBtn.Location = new System.Drawing.Point(22, 67);
            this.dSearchBtn.Name = "dSearchBtn";
            this.dSearchBtn.Size = new System.Drawing.Size(89, 34);
            this.dSearchBtn.TabIndex = 1;
            this.dSearchBtn.Text = "배달기록 검색";
            this.dSearchBtn.UseVisualStyleBackColor = true;
            this.dSearchBtn.Click += new System.EventHandler(this.dSearchBtn_Click);
            // 
            // driverIdTxt
            // 
            this.driverIdTxt.Location = new System.Drawing.Point(92, 29);
            this.driverIdTxt.Name = "driverIdTxt";
            this.driverIdTxt.Size = new System.Drawing.Size(100, 21);
            this.driverIdTxt.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox9);
            this.tabPage3.Controls.Add(this.groupBox11);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1096, 529);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "고객문의";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.CkReplyBtn);
            this.groupBox9.Controls.Add(this.label8);
            this.groupBox9.Controls.Add(this.InqNumTxt);
            this.groupBox9.Controls.Add(this.ReplyBtn);
            this.groupBox9.Location = new System.Drawing.Point(92, 37);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(218, 111);
            this.groupBox9.TabIndex = 15;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "고객문의 관리";
            // 
            // CkReplyBtn
            // 
            this.CkReplyBtn.Location = new System.Drawing.Point(121, 67);
            this.CkReplyBtn.Name = "CkReplyBtn";
            this.CkReplyBtn.Size = new System.Drawing.Size(89, 34);
            this.CkReplyBtn.TabIndex = 11;
            this.CkReplyBtn.Text = "문의내용 확인";
            this.CkReplyBtn.UseVisualStyleBackColor = true;
            this.CkReplyBtn.Click += new System.EventHandler(this.CkReplyBtn_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 12);
            this.label8.TabIndex = 10;
            this.label8.Text = "문의 글 번호 : ";
            // 
            // InqNumTxt
            // 
            this.InqNumTxt.Location = new System.Drawing.Point(97, 25);
            this.InqNumTxt.Name = "InqNumTxt";
            this.InqNumTxt.Size = new System.Drawing.Size(100, 21);
            this.InqNumTxt.TabIndex = 10;
            // 
            // ReplyBtn
            // 
            this.ReplyBtn.Location = new System.Drawing.Point(8, 67);
            this.ReplyBtn.Name = "ReplyBtn";
            this.ReplyBtn.Size = new System.Drawing.Size(89, 34);
            this.ReplyBtn.TabIndex = 0;
            this.ReplyBtn.Text = "문의 답글";
            this.ReplyBtn.UseVisualStyleBackColor = true;
            this.ReplyBtn.Click += new System.EventHandler(this.ReplyBtn_Click);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.inqCounter);
            this.groupBox11.Controls.Add(this.inqDataGridView);
            this.groupBox11.Location = new System.Drawing.Point(92, 154);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(541, 269);
            this.groupBox11.TabIndex = 10;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "고객문의";
            // 
            // inqCounter
            // 
            this.inqCounter.AutoSize = true;
            this.inqCounter.Location = new System.Drawing.Point(467, 17);
            this.inqCounter.Name = "inqCounter";
            this.inqCounter.Size = new System.Drawing.Size(51, 12);
            this.inqCounter.TabIndex = 1;
            this.inqCounter.Text = "총 000개";
            // 
            // inqDataGridView
            // 
            this.inqDataGridView.AllowUserToAddRows = false;
            this.inqDataGridView.AllowUserToDeleteRows = false;
            this.inqDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.inqDataGridView.Location = new System.Drawing.Point(23, 32);
            this.inqDataGridView.Name = "inqDataGridView";
            this.inqDataGridView.ReadOnly = true;
            this.inqDataGridView.RowHeadersVisible = false;
            this.inqDataGridView.RowTemplate.Height = 23;
            this.inqDataGridView.Size = new System.Drawing.Size(495, 214);
            this.inqDataGridView.TabIndex = 0;
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1105, 556);
            this.Controls.Add(this.tabControl1);
            this.Name = "AdminForm";
            this.Text = "AdminForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.AdminForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.userDataGridView)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.orderDataGridView)).EndInit();
            this.groupbox2.ResumeLayout(false);
            this.groupbox2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.driverDataGridView)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dOrderDataGridView)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inqDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.DataGridView userDataGridView;
        private System.Windows.Forms.Label userCounter;
        private System.Windows.Forms.GroupBox groupBox4;
        internal System.Windows.Forms.DataGridView orderDataGridView;
        private System.Windows.Forms.Label orderCounter;
        private System.Windows.Forms.GroupBox groupbox2;
        private System.Windows.Forms.TextBox userIdTxt;
        private System.Windows.Forms.Button SearchBtn;
        private System.Windows.Forms.Button DeleteBtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label driverCounter;
        internal System.Windows.Forms.DataGridView driverDataGridView;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label dOrderCounter;
        internal System.Windows.Forms.DataGridView dOrderDataGridView;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button dDeleteBtn;
        private System.Windows.Forms.Button dSearchBtn;
        private System.Windows.Forms.TextBox driverIdTxt;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label inqCounter;
        internal System.Windows.Forms.DataGridView inqDataGridView;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button CkReplyBtn;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox InqNumTxt;
        private System.Windows.Forms.Button ReplyBtn;
    }
}