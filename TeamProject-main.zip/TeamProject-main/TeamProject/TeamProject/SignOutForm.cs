﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeamProject
{
    public partial class SignOutForm : Form
    {
        private DBClass dbClass;
        private string LoggedInUserId;

        public SignOutForm(string loggedInUserId)
        {
            InitializeComponent();
            dbClass = new DBClass();

            // 생성자에서 userId 초기화
            LoggedInUserId = loggedInUserId;
            // 해당 ID를 텍스트 박스에 표시
            txtid.Text = LoggedInUserId;
            // 텍스트 박스를 읽기 전용으로 설정
            txtid.ReadOnly = true;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            string enteredPassword = txtpwd.Text;

            // 데이터베이스에 연결
            if (dbClass.ConnectToDatabase())
            {
                try
                {
                    // 비밀번호 확인
                    if (CheckPassword(enteredPassword))
                    {
                        DialogResult result = MessageBox.Show("회원 탈퇴를 진행하시겠습니까?", "확인", MessageBoxButtons.YesNo);

                        if (result == DialogResult.Yes)
                        {
                            // 회원 탈퇴 성공 메시지
                            MessageBox.Show("회원 탈퇴 성공 지금까지 감사했습니다.");

                            // 로그인한 userId 값을 가진 Inquiries 테이블에서 레코드 삭제
                            DeleteFromInquiries(LoggedInUserId);

                            // 로그인한 userId 값을 가진 Orders 테이블에서 레코드 삭제
                            DeleteFromOrders(LoggedInUserId);

                            // 로그인한 userId 값을 가진 UserInfo 테이블에서 레코드 삭제
                            DeleteFromUserInfo(LoggedInUserId);

                            // MypageForm에 회원 탈퇴 성공 이벤트 호출
                            ((MypageForm)Application.OpenForms["MypageForm"]).OnSignOutSuccess();

                            // 폼 닫기
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("비밀번호가 틀렸습니다.");
                        }
                    }
                }
                finally
                {
                    // 데이터베이스 연결 해제
                    dbClass.DisconnectFromDatabase();
                }
            }
            else
            {
                MessageBox.Show("데이터베이스에 연결할 수 없습니다.");
            }
        }


        private bool CheckPassword(string enteredPassword)
        {
            try
            {
                // DriverInfo 테이블에서 비밀번호 가져오기
                string query = $"SELECT Password FROM UserInfo WHERE userId = '{LoggedInUserId}'";
                dbClass.DCom.CommandText = query;

                string correctPassword = dbClass.DCom.ExecuteScalar().ToString();

                // 입력한 비밀번호와 저장된 비밀번호 비교
                return enteredPassword == correctPassword;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"비밀번호 확인 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
                return false;
            }
        }

        private void DeleteFromInquiries(string userId)
        {
            try
            {
                // DriverOrders 테이블에서 해당 driverId의 레코드 삭제
                string deleteQuery = $"DELETE FROM Inquiries WHERE userId = '{userId}'";
                dbClass.DCom.CommandText = deleteQuery;
                dbClass.DCom.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Inquiries 삭제 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
        }

        private void DeleteFromOrders(string userId)
        {
            try
            {
                // DriverInfo 테이블에서 해당 driverId의 레코드 삭제
                string deleteQuery = $"DELETE FROM Orders WHERE userId = '{userId}'";
                dbClass.DCom.CommandText = deleteQuery;
                dbClass.DCom.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Orders 삭제 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
        }

        private void DeleteFromUserInfo(string userId)
        {
            try
            {
                // DriverInfo 테이블에서 해당 driverId의 레코드 삭제
                string deleteQuery = $"DELETE FROM UserInfo WHERE userId = '{userId}'";
                dbClass.DCom.CommandText = deleteQuery;
                dbClass.DCom.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"UserInfo 삭제 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
        }


    }
}
