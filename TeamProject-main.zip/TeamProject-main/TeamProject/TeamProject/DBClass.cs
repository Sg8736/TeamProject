﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oracle.DataAccess.Client;//ADO.Net 개체 참조
using System.Data; //DataSet 개체 참조
using System.Windows.Forms; //MessageBox 개체 참조

namespace TeamProject
{
    // 텍스트 공백 제거 클래스
    public static class TextTrim
    {
        // 문자열의 앞뒤 공백을 제거하는 메서드
        public static string TrimWhitespace(string input)
        {
            // 앞뒤의 여백을 제거합니다.
            return input?.Trim();
        }
    }

    // 데이터베이스 기능을 제공하는 클래스
    class DBClass
    {
        private OracleConnection connection; // 데이터 베이스 연결 담당하는 객체
        private OracleCommand dCom; // 데이터베이스 쿼리를 실행하는 객체
        private OracleDataAdapter dA; // 데이터베이스에서 데이터를 가져오는 객체
        private DataSet dS; // 데이터를 저장하는 객체

        // 오라클 데이터베이스 연결 문자열
        private const string connectionString = "User Id=hong1; Password=1111; Data Source=(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = localhost)(PORT = 1521)) (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = xe) ) );";
        // 사용자 인증 쿼리
        private const string authenticateUserQuery = "SELECT COUNT(*) FROM USERINFO WHERE UserId = :UserId AND Password = :Password";
        // 관리자 인증 쿼리
        private const string authenticateAdminQuery = "SELECT COUNT(*) FROM ADMININFO WHERE AdminId = :AdminId AND APassword = :APassword";
        // 중복 사용자 아이디 체크 쿼리
        private const string checkDuplicateUserIdQuery = "SELECT COUNT(*) FROM USERINFO WHERE UserId = :UserId";
        // 사용자 등록 쿼리
        private const string registerUserQuery = "INSERT INTO USERINFO (UserId, Password, Name, Address, Phone, Email, SignUpDate) VALUES (:UserId, :Password, :Name, :Address, :Phone, :Email, :SignUpDate)";


        public OracleCommand DCom { get { return dCom; } set { dCom = value; } }
        public OracleDataAdapter DA { get { return dA; } set { dA = value; } }
        public DataSet DS { get { return dS; } set { dS = value; } }

        public bool IsAdmin { get; private set; }

        public DBClass()
        {
            connection = new OracleConnection(connectionString);
            dCom = new OracleCommand();
            dCom.Connection = connection;
            dA = new OracleDataAdapter();
            DS = new DataSet();
            DS.Tables.Add("USERINFO");
            DS.Tables.Add("ORDERS");
            DS.Tables.Add("INQUIRIES");
            DS.Tables.Add("DriverInfo");
            DS.Tables.Add("DOrders");
        }

        // 데이터베이스 연결 메서드
        public bool ConnectToDatabase()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("DB 연결 오류: " + ex.Message);
                return false;
            }
        }

        // 일반 쿼리 실행 메서드
        private int ExecuteQuery(string query, OracleParameter[] parameters)
        {
            // OracleCommand를 사용하여 쿼리를 실행하고 영향을 받은 행 수를 반환
            using (OracleCommand command = new OracleCommand(query, connection))
            {
                command.Parameters.AddRange(parameters);
                return command.ExecuteNonQuery();
            }
        }

        // 스칼라 쿼리 실행 메서드
        private int ExecuteScalarQuery(string query, OracleParameter[] parameters)
        {
            // OracleCommand를 사용하여 스칼라 쿼리를 실행하고 결과를 정수로 반환
            using (OracleCommand command = new OracleCommand(query, connection))
            {
                command.Parameters.AddRange(parameters);
                return Convert.ToInt32(command.ExecuteScalar());
            }
        }

        // 데이터베이스 연결 해제
        public void DisconnectFromDatabase()
        {
            if (connection.State == ConnectionState.Open)
                connection.Close();
        }

        // 예외 처리 메서드
        private void HandleException(string errorMessage, Exception ex)
        {
            // 예외 던지기 대신 호출자에서 처리하도록 변경
            throw new Exception(errorMessage, ex);
        }

        // 사용자 인증
        public bool AuthenticateUser(string userId, string password)
        {
            try
            {
                // TextTrimdmf 사용하여 공백 제거
                userId = TextTrim.TrimWhitespace(userId);
                password = TextTrim.TrimWhitespace(password);

                // 인증 쿼리 실행 후 결과를 반환
                OracleParameter[] parameters = {
                new OracleParameter(":UserId", OracleDbType.Varchar2) { Value = userId },
                new OracleParameter(":Password", OracleDbType.Varchar2) { Value = password }
            };

                return ExecuteScalarQuery(authenticateUserQuery, parameters) > 0;
            }
            catch (Exception ex)
            {
                HandleException("인증 오류", ex);
                return false;
            }
        }

        // 관리자 인증
        public bool AuthenticateAdmin(string adminId, string aPassword)
        {
            // TextTrim를 사용하여 공백 제거
            adminId = TextTrim.TrimWhitespace(adminId);
            aPassword = TextTrim.TrimWhitespace(aPassword);

            try
            {
                // 관리자 인증 쿼릴 실행 후 결과를 반환하고 IsAdmin 속성 설정
                OracleParameter[] parameters = {
                new OracleParameter(":AdminId", OracleDbType.Varchar2) { Value = adminId },
                new OracleParameter(":APassword", OracleDbType.Varchar2) { Value = aPassword }
            };

                // 여기서 AuthenticateAdmin 메서드의 반환값이 true이면서 IsAdmin 속성을 true로 설정
                IsAdmin = ExecuteScalarQuery(authenticateAdminQuery, parameters) > 0;
                return IsAdmin;
            }
            catch (Exception ex)
            {
                HandleException("인증 오류", ex);
                return false;
            }
        }

        // 중복 사용자 아이디 체크
        public bool CheckDuplicateUserId(string userId)
        {
            try
            {
                // 중복 체크 쿼리 실행 후 결과를 반환
                OracleParameter[] parameters = {
                new OracleParameter(":UserId", OracleDbType.Varchar2) { Value = userId }
            };

                return ExecuteScalarQuery(checkDuplicateUserIdQuery, parameters) > 0;
            }
            catch (Exception ex)
            {
                HandleException("중복 체크 오류", ex);
                return false;
            }
        }

        // 사용자 등록
        // 회원가입 실패 시 테이블에 값이 저장되는 문제 수정
        public bool RegisterUser(string userId, string password, string name, string address, string phone, string email)
        {
            userId = TextTrim.TrimWhitespace(userId);
            password = TextTrim.TrimWhitespace(password);
            name = TextTrim.TrimWhitespace(name);
            phone = TextTrim.TrimWhitespace(phone);
            address = TextTrim.TrimWhitespace(address);
            email = TextTrim.TrimWhitespace(email);

            try
            {
                using (OracleTransaction transaction = connection.BeginTransaction())
                {
                    try
                    {
                        OracleParameter[] parameters = {
                        new OracleParameter(":UserId", OracleDbType.Varchar2) { Value = userId },
                        new OracleParameter(":Password", OracleDbType.Varchar2) { Value = password },
                        new OracleParameter(":Name", OracleDbType.Varchar2) { Value = name },
                        new OracleParameter(":Address", OracleDbType.Varchar2) { Value = address },
                        new OracleParameter(":Phone", OracleDbType.Varchar2) { Value = phone },
                        new OracleParameter(":Email", OracleDbType.Varchar2) { Value = email },
                        new OracleParameter(":SignUpDate", OracleDbType.Date) { Value = DateTime.Now },
                    };

                        dCom.CommandText = registerUserQuery;
                        dCom.Parameters.AddRange(parameters);
                        dCom.ExecuteNonQuery();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        Console.WriteLine($"회원가입 중 오류 발생: {ex.Message}");
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"회원가입 중 오류 발생: {ex.Message}");
                return false;
            }
        }

    // 답변을 데이터베이스에 저장
    public void SaveReplyToDatabase(int inqId, string reply)
        {
            try
            {
                // inqId를 사용하여 Inquiries 테이블의 해당 레코드를 찾아 업데이트
                string updateQuery = "UPDATE Inquiries SET reply = :Reply, hasReply = 'Y' WHERE inqId = :InqId";
                OracleParameter[] parameters = {
            new OracleParameter(":Reply", OracleDbType.Varchar2) { Value = reply },
            new OracleParameter(":InqId", OracleDbType.Int32) { Value = inqId }
        };

                // ExecuteQuery 메서드를 호출
                ExecuteQuery(updateQuery, parameters);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"DB 저장 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
        }

    }
}