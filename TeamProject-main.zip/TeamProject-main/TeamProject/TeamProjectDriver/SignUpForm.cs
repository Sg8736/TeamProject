﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;


namespace TeamProjectDriver
{
    public partial class SignUpForm : Form
    {
        private DBClass dbClass;

        public SignUpForm()
        {
            InitializeComponent();
            dbClass = new DBClass();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dbClass.ConnectToDatabase())
            {
                try
                {
                    string driverId = txtid.Text;
                    string dPhone = $"{txtphone1.Text}-{txtphone2.Text}-{txtphone3.Text}";

                    string duplicateInfo = dbClass.CheckDuplicateDriverInfo(driverId, dPhone);

                    if (duplicateInfo != null)
                    {
                        MessageBox.Show(duplicateInfo, "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        // 회원가입 처리
                        if (dbClass.RegisterDriver(driverId, txtpwd.Text, txtname.Text, dPhone))
                        {
                            MessageBox.Show("회원가입 완료");
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("회원가입 실패");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"오류 발생: {ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    // 연결 안전하게 해제
                    dbClass.DisconnectFromDatabase();
                }
            }
        }
    }
}