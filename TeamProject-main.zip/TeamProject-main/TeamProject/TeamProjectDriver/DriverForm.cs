﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;

namespace TeamProjectDriver
{
    public partial class DriverForm : Form
    {
        private DBClass dbClass;
        private GroupBox userControlsGroupBox;
        private TextBox loggedInTextBox;
        private Button logoutButton;
        private Button loginButton;

        private string loggedInDriverId; // 추가: 로그인한 driverId 저장
        public string LoggedInDriverId { get; private set; }
        private bool isLoggedIn = false;

        public DriverForm()
        {
            InitializeComponent();
            dbClass = new DBClass();
            userControlsGroupBox = LoginGroup;

            loginButton = LoginBtn;
            loginButton.Click -= LoginButton_Click;
            loginButton.Click += LoginButton_Click;
        }


        // = = = = = = = = = = = = = = = = 로그인 회원 가입 기능= = = = = = = = = = = = = = = =
        private void LoginButton_Click(object sender, EventArgs e)
        {
            LoginForm loginForm = new LoginForm();
            loginForm.ShowDialog();

            if (loginForm.LoginSuccess)
            {
                LoggedInDriverId = loginForm.LoggedInDriverId;

                UpdateUIOnLogin(loginForm.LoggedInDriverId);
            }
            else
            {
                MessageBox.Show("로그인에 실패했습니다.");
            }
        }

        private void ShowLoginSuccessMessage()
        {
            MessageBox.Show("환영합니다!");
        }

        private void SignUpButton_Click(object sender, EventArgs e)
        {
            AgreementForm agreementForm = new AgreementForm();
            agreementForm.ShowDialog();
        }

        private TextBox CreateTextBox()
        {
            TextBox textBox1 = new TextBox
            {
                ReadOnly = true,
                Location = new Point(12, 31)
            };

            this.Controls.Add(textBox1);
            return textBox1;
        }

        private Button CreateLogoutButton()
        {
            Button button = new Button
            {
                Text = "로그아웃",
                Location = new Point(112, 30)
            };

            button.Click += LogoutButton_Click;
            this.Controls.Add(button);
            return button;
        }

        private void LogoutButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("로그아웃 되었습니다.");

            loggedInTextBox.Visible = false;
            logoutButton.Visible = false;

            LoginBtn.Visible = true;
            SignUpBtn.Visible = true;

            // 주문 목록 감추기
            OrderDataGridView.DataSource = null;
            DriverOrdersDataGridView.DataSource = null;
            DriverOrders_counter();
            Orders_counter();
            // 로그인 상태 갱신
            isLoggedIn = false;
        }

        private void UpdateUIOnLogin(string loggedInDriverId)
        {
            if (loggedInTextBox == null)
            {
                loggedInTextBox = CreateTextBox();
                userControlsGroupBox.Controls.Add(loggedInTextBox);
            }

            loggedInTextBox.Text = "ID: " + loggedInDriverId;
            loggedInTextBox.Visible = true;

            if (logoutButton == null)
            {
                logoutButton = CreateLogoutButton();
                userControlsGroupBox.Controls.Add(logoutButton);
            }

            // 로그인한 driverId 저장
            this.loggedInDriverId = loggedInDriverId;

            // DriverIdTxt에 로그인한 배달기사의 아이디 설정
            DriverIdTxt.Text = loggedInDriverId;

            // 로그인 상태 갱신
            isLoggedIn = true;

            logoutButton.Visible = true;

            LoginBtn.Visible = false;
            SignUpBtn.Visible = false;

            ShowLoginSuccessMessage();

            // 주문 목록 표시
            DisplayUserOrders();
            Orders_header();
            Orders_counter();

            DisplayDriverOrders();
            DriverOrders_header();
            DriverOrders_counter();

        }
        // = = = = = = = = = = = = = = = = 로그인 회원 가입 기능= = = = = = = = = = = = = = = = 


        // 그리드 뷰 셀 클릭 이벤트 핸들러 등록
        private void DriverForm_Load(object sender, EventArgs e)
        {
            // DB 연결
            if (dbClass.ConnectToDatabase())
            {
                // inqDataGridView의 CellClick 이벤트 핸들러 등록
                OrderDataGridView.CellClick += OrdersDataGridView_CellClick;
                DriverOrdersDataGridView.CellClick += DriverOrdersDataGridView_CellClick;
            }
            else
            {
                MessageBox.Show("DB 연결에 실패했습니다.");
                this.Close();
            }
        }

        // 고객의 주문 목록 표시 기능
        public void Orders_counter()
        {
            int i = OrderDataGridView.RowCount;
            OrderCounter.Text = $"주문 : 총 {i} 개";
        }

        private void DisplayUserOrders()
        {
            // Orders 테이블을 사용하여 주문 목록을 가져오는 쿼리
            string sqlstr = $"SELECT * FROM Orders WHERE OrderStatus = '배달준비' ORDER BY orderId ASC";
            dbClass.DCom.CommandText = sqlstr;

            try
            {
                // ORDERS 테이블을 지우고, 주문 목록을 다시 채움
                if (dbClass.DS.Tables["Orders"] != null)
                {
                    dbClass.DS.Tables["Orders"].Clear(); // 중복 데이터 제거
                }

                dbClass.DA.SelectCommand = dbClass.DCom;
                dbClass.DA.Fill(dbClass.DS, "Orders");

                // DataGridView에 주문 목록 표시
                OrderDataGridView.DataSource = dbClass.DS.Tables["Orders"].DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"주문 목록 표시 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
        }

        public void Orders_header()
        {
            // Orders 테이블의 열 헤더 설정
            OrderDataGridView.Columns[0].HeaderText = "주문번호";
            OrderDataGridView.Columns[1].HeaderText = "주소";
            OrderDataGridView.Columns[2].HeaderText = "주문상태";
            OrderDataGridView.Columns[3].HeaderText = "총액";
            OrderDataGridView.Columns[4].HeaderText = "ID";

            // 각 열의 너비 설정
            OrderDataGridView.Columns[0].Width = 80;
            OrderDataGridView.Columns[1].Width = 150;
            OrderDataGridView.Columns[2].Width = 90;
            OrderDataGridView.Columns[3].Width = 70;
            OrderDataGridView.Columns[4].Width = 70;
        }

        // 새로 고침 버튼 기능
        private void ReloadBtn_Click(object sender, EventArgs e)
        {
            // 로그인 상태인 경우에만 주문 목록을 다시 불러오기
            if (isLoggedIn)
            {
                DisplayUserOrders();
                Orders_header();
                Orders_counter();
            }
        }
        
        // 주문 목록 그리드 뷰 셀 클릭 이벤트
        private void OrdersDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < OrderDataGridView.Rows.Count)
            {
                // 선택한 행의 첫 번째 열 값을 가져와서 텍스트 박스에 표시
                var cellValue = OrderDataGridView.Rows[e.RowIndex].Cells[0].Value;
                if (cellValue != null)
                {
                    string selectedId = OrderDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
                    SelcetOrderTxt.Text = selectedId;
                }
            }
        }

        // 선택한 주문을 픽업 하는 기능
        private void PickUpBtn_Click(object sender, EventArgs e)
        {
            // 선택한 주문 번호 가져오기
            string selectedOrderId = SelcetOrderTxt.Text;

            // 선택한 주문 번호가 없으면 메시지 출력
            if (string.IsNullOrEmpty(selectedOrderId))
            {
                MessageBox.Show("주문을 먼저 선택하세요.");
                return;
            }

            // 확인 여부 다이얼로그 표시
            DialogResult result = MessageBox.Show("해당 주문을 픽업 하시겠습니까?", "확인", MessageBoxButtons.YesNo);

            // 사용자가 확인을 선택한 경우
            if (result == DialogResult.Yes)
            {
                // 데이터베이스 업데이트
                UpdateOrderStatus(selectedOrderId, "배달중");

                // DriverOrders에 새로운 레코드 추가
                InsertIntoDriverOrders(LoggedInDriverId, selectedOrderId, DateTime.Now);

                // 그리드 뷰와 카운터 새로고침
                DisplayUserOrders();
                Orders_header();
                Orders_counter();

                DisplayDriverOrders();
                DriverOrders_header();
                DriverOrders_counter();

                SelcetOrderTxt.Text = null;
            }
            else
            {
                // 사용자가 취소를 선택한 경우
                MessageBox.Show("주문 픽업이 취소되었습니다.");
            }
        }

        // 주문 픽업, 픽업 취소 시 Orders 테이블의 OrderStatus의 값을 변경시키는 기능
        private void UpdateOrderStatus(string orderId, string newStatus)
        {
            try
            {
                // 주문 상태 업데이트 쿼리
                string updateQuery = $"UPDATE Orders SET OrderStatus = '{newStatus}' WHERE orderId = '{orderId}'";
                dbClass.DCom.CommandText = updateQuery;
                dbClass.DCom.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"주문 상태 업데이트 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
        }

        // 픽업 시 DriverOrders 테이블에 배달번호 픽업 한 주문 번호 픽업을 시작한 시간을 저장
        private void InsertIntoDriverOrders(string driverId, string orderId, DateTime orderStartDate)
        {
            try
            {
                // DriverOrders에 새로운 레코드 추가 쿼리
                string insertQuery = $"INSERT INTO DriverOrders (dOrderId, driverId, orderId, orderStartDate) " +
                                     $"VALUES (dOrderId_sequence.NEXTVAL, '{driverId}', '{orderId}', TO_TIMESTAMP('{orderStartDate.ToString("yyyy-MM-dd HH:mm:ss")}', 'YYYY-MM-DD HH24:MI:SS'))";
                dbClass.DCom.CommandText = insertQuery;
                dbClass.DCom.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"DriverOrders 레코드 추가 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
        }

        // 배달 기록 셀 클릭 이벤트
        private void DriverOrdersDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < DriverOrdersDataGridView.Rows.Count)
            {
                // 선택한 행의 첫 번째 열 값을 가져와서 텍스트 박스에 표시
                var cellValue = DriverOrdersDataGridView.Rows[e.RowIndex].Cells[0].Value;
                if (cellValue != null)
                {
                    string selectedId = DriverOrdersDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
                    DriverOrdertxt.Text = selectedId;
                }
            }
        }

        // 배달 기록에서 선택한 배달의 주문 픽업을 취소
        private void PickUpCancleBtn_Click(object sender, EventArgs e)
        {
            // 선택한 배달 번호 가져오기
            string selectedDeliveryOrderId = DriverOrdertxt.Text;

            // 선택한 배달 번호가 없으면 메시지 출력
            if (string.IsNullOrEmpty(selectedDeliveryOrderId))
            {
                MessageBox.Show("배달을 먼저 선택하세요.");
                return;
            }

            // 확인 여부 다이얼로그 표시
            DialogResult result = MessageBox.Show("해당 배달을 취소 하시겠습니까?", "확인", MessageBoxButtons.YesNo);

            // 사용자가 확인을 선택한 경우
            if (result == DialogResult.Yes)
            {
                // 배달이 취소되었으므로 해당 배달의 주문 번호 가져오기
                string selectedOrderId = GetOrderIdByDeliveryOrderId(selectedDeliveryOrderId);

                // 주문 상태 업데이트
                UpdateOrderStatus(selectedOrderId, "배달준비");

                // DriverOrders 테이블에서 해당 배달 삭제
                DeleteFromDriverOrders(selectedDeliveryOrderId);

                // 그리드 뷰와 카운터 새로고침
                DisplayUserOrders();
                Orders_header();
                Orders_counter();

                DisplayDriverOrders();
                DriverOrders_header();
                DriverOrders_counter();

                DriverOrdertxt.Text = null;
            }
            else
            {
                // 사용자가 취소를 선택한 경우
                MessageBox.Show("배달 취소가 취소되었습니다.");
            }
        }

        // 주문 번호 가져오기 배달번호(dOrderId)의 값을 가지고 DriverOrders테이블의 orderId 값을 찾는 기능
        private string GetOrderIdByDeliveryOrderId(string deliveryOrderId)
        {
            string orderId = string.Empty;

            // DriverOrders 테이블에서 주문 번호 가져오기
            string query = $"SELECT orderId FROM DriverOrders WHERE dOrderId = '{deliveryOrderId}'";
            dbClass.DCom.CommandText = query;

            try
            {
                orderId = dbClass.DCom.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"주문 번호 가져오기 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }

            return orderId;
        }

        // DriverOrders 테이블에서 해당 배달 삭제 메서드
        private void DeleteFromDriverOrders(string deliveryOrderId)
        {
            try
            {
                // DriverOrders 테이블에서 해당 배달 삭제 쿼리
                string deleteQuery = $"DELETE FROM DriverOrders WHERE dOrderId = '{deliveryOrderId}'";
                dbClass.DCom.CommandText = deleteQuery;
                dbClass.DCom.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"DriverOrders 삭제 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
        }

        // 배달 완료 이벤트
        private void EndBtn_Click(object sender, EventArgs e)
        {
            // 선택한 배달 번호 가져오기
            string selectedDeliveryOrderId = DriverOrdertxt.Text;

            // 선택한 배달 번호가 없으면 메시지 출력
            if (string.IsNullOrEmpty(selectedDeliveryOrderId))
            {
                MessageBox.Show("배달을 먼저 선택하세요.");
                return;
            }

            // 확인 여부 다이얼로그 표시
            DialogResult result = MessageBox.Show("배달을 완료하시겠습니까?", "확인", MessageBoxButtons.YesNo);

            // 사용자가 확인을 선택한 경우
            if (result == DialogResult.Yes)
            {
                // 배달 완료 처리
                CompleteDelivery(selectedDeliveryOrderId);
            }
            else
            {
                // 사용자가 취소를 선택한 경우
                MessageBox.Show("배달 완료가 취소되었습니다.");
            }
        }

        // 배달 완료 처리 메서드
        private void CompleteDelivery(string deliveryOrderId)
        {
            // 배달이 완료된 주문 번호 가져오기
            string orderId = GetOrderIdByDeliveryOrderId(deliveryOrderId);

            // 주문 상태 업데이트
            UpdateOrderStatus(orderId, "배달완료");

            // 배달 완료 시간 업데이트
            UpdateDeliveryEndDate(deliveryOrderId, DateTime.Now);

            // 그리드 뷰와 카운터 새로고침
            DisplayUserOrders();
            Orders_header();
            Orders_counter();

            DisplayDriverOrders();
            DriverOrders_header();
            DriverOrders_counter();


            // 선택한 주문번호 초기화
            DriverOrdertxt.Text = null;

            MessageBox.Show("배달이 완료되었습니다.");
        }

        // 배달 완료 시간 업데이트 메서드
        private void UpdateDeliveryEndDate(string deliveryOrderId, DateTime endDate)
        {
            try
            {
                // 배달 완료 시간 업데이트 쿼리
                string updateQuery = $"UPDATE DriverOrders SET orderEndDate = TO_TIMESTAMP('{endDate.ToString("yyyy-MM-dd HH:mm:ss")}', 'YYYY-MM-DD HH24:MI:SS') " +
                                     $"WHERE dOrderId = '{deliveryOrderId}'";
                dbClass.DCom.CommandText = updateQuery;
                dbClass.DCom.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"배달 완료 시간 업데이트 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
        }
        

        // 메인 페이지 배달 기록 기능
        public void DriverOrders_counter()
        {
            int i = DriverOrdersDataGridView.RowCount;
            DriverOrdersCounter.Text = $"픽업한 주문 : {i} 개";
        }

        private void DisplayDriverOrders()
        {
            if (isLoggedIn)
            {
                // 추가: DriverOrders 테이블을 사용하여 로그인한 배달기사의 주문 목록을 가져오는 쿼리
                string driverOrdersQuery = $"SELECT dOrderId, orderId, orderStartDate FROM DriverOrders WHERE driverId = '{loggedInDriverId}' AND orderEndDate IS NULL";
                dbClass.DCom.CommandText = driverOrdersQuery;

                try
                {
                    // DriverOrders 테이블을 지우고, 주문 목록을 다시 채움
                    if (dbClass.DS.Tables["DriverOrders"] != null)
                    {
                        dbClass.DS.Tables["DriverOrders"].Clear(); // 중복 데이터 제거
                    }

                    dbClass.DA.SelectCommand = dbClass.DCom;
                    dbClass.DA.Fill(dbClass.DS, "DriverOrders");

                    // DataGridView에 주문 목록 표시
                    DriverOrdersDataGridView.DataSource = dbClass.DS.Tables["DriverOrders"].DefaultView;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"운전자 주문 목록 표시 오류: {ex.Message}\nStackTrace: {ex.StackTrace}");
                }
            }
        }

        public void DriverOrders_header()
        {
            // Orders 테이블의 열 헤더 설정
            DriverOrdersDataGridView.Columns[0].HeaderText = "배달번호";
            DriverOrdersDataGridView.Columns[1].HeaderText = "주문번호";
            DriverOrdersDataGridView.Columns[2].HeaderText = "배달시작 시간";

            // 각 열의 너비 설정
            DriverOrdersDataGridView.Columns[0].Width = 100;
            DriverOrdersDataGridView.Columns[1].Width = 100;
            DriverOrdersDataGridView.Columns[2].Width = 260;
        }




        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            
        }

        private void SignOutBtn_Click(object sender, EventArgs e)
        {

        }
    }
}