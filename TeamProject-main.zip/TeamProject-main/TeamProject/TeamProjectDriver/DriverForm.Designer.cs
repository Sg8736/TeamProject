﻿
namespace TeamProjectDriver
{
    partial class DriverForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.DriverOrdersCounter = new System.Windows.Forms.Label();
            this.DriverOrdersDataGridView = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.EndBtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.DriverOrdertxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SelcetOrderTxt = new System.Windows.Forms.TextBox();
            this.PickUpCancleBtn = new System.Windows.Forms.Button();
            this.PickUpBtn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ReloadBtn = new System.Windows.Forms.Button();
            this.OrderCounter = new System.Windows.Forms.Label();
            this.OrderDataGridView = new System.Windows.Forms.DataGridView();
            this.LoginGroup = new System.Windows.Forms.GroupBox();
            this.SignUpBtn = new System.Windows.Forms.Button();
            this.LoginBtn = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.DriverOrdersCompleteCounter = new System.Windows.Forms.Label();
            this.DriverOrdersCompleteDataGridView = new System.Windows.Forms.DataGridView();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.SignOutBtn = new System.Windows.Forms.Button();
            this.UpdateBtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.DriverIdTxt = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DriverOrdersDataGridView)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OrderDataGridView)).BeginInit();
            this.LoginGroup.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DriverOrdersCompleteDataGridView)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(509, 766);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.LoginGroup);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(501, 740);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "메인페이지";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.DriverOrdersCounter);
            this.groupBox3.Controls.Add(this.DriverOrdersDataGridView);
            this.groupBox3.Location = new System.Drawing.Point(9, 530);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(489, 204);
            this.groupBox3.TabIndex = 8;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "픽업 주문 표기";
            // 
            // DriverOrdersCounter
            // 
            this.DriverOrdersCounter.AutoSize = true;
            this.DriverOrdersCounter.Location = new System.Drawing.Point(361, 24);
            this.DriverOrdersCounter.Name = "DriverOrdersCounter";
            this.DriverOrdersCounter.Size = new System.Drawing.Size(111, 12);
            this.DriverOrdersCounter.TabIndex = 8;
            this.DriverOrdersCounter.Text = "픽업한 주문 : 000개";
            // 
            // DriverOrdersDataGridView
            // 
            this.DriverOrdersDataGridView.AllowUserToAddRows = false;
            this.DriverOrdersDataGridView.AllowUserToDeleteRows = false;
            this.DriverOrdersDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DriverOrdersDataGridView.Location = new System.Drawing.Point(16, 39);
            this.DriverOrdersDataGridView.Name = "DriverOrdersDataGridView";
            this.DriverOrdersDataGridView.ReadOnly = true;
            this.DriverOrdersDataGridView.RowHeadersVisible = false;
            this.DriverOrdersDataGridView.RowTemplate.Height = 23;
            this.DriverOrdersDataGridView.Size = new System.Drawing.Size(456, 148);
            this.DriverOrdersDataGridView.TabIndex = 7;
            this.DriverOrdersDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DriverOrdersDataGridView_CellClick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.EndBtn);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.DriverOrdertxt);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.SelcetOrderTxt);
            this.groupBox2.Controls.Add(this.PickUpCancleBtn);
            this.groupBox2.Controls.Add(this.PickUpBtn);
            this.groupBox2.Location = new System.Drawing.Point(219, 400);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(276, 124);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "배달 픽업/취소";
            // 
            // EndBtn
            // 
            this.EndBtn.Location = new System.Drawing.Point(195, 88);
            this.EndBtn.Name = "EndBtn";
            this.EndBtn.Size = new System.Drawing.Size(75, 23);
            this.EndBtn.TabIndex = 6;
            this.EndBtn.Text = "배달 완료";
            this.EndBtn.UseVisualStyleBackColor = true;
            this.EndBtn.Click += new System.EventHandler(this.EndBtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(63, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 5;
            this.label2.Text = "픽업번호 : ";
            // 
            // DriverOrdertxt
            // 
            this.DriverOrdertxt.Location = new System.Drawing.Point(134, 56);
            this.DriverOrdertxt.Name = "DriverOrdertxt";
            this.DriverOrdertxt.Size = new System.Drawing.Size(100, 21);
            this.DriverOrdertxt.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(65, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "주문번호 : ";
            // 
            // SelcetOrderTxt
            // 
            this.SelcetOrderTxt.Location = new System.Drawing.Point(134, 29);
            this.SelcetOrderTxt.Name = "SelcetOrderTxt";
            this.SelcetOrderTxt.Size = new System.Drawing.Size(100, 21);
            this.SelcetOrderTxt.TabIndex = 2;
            // 
            // PickUpCancleBtn
            // 
            this.PickUpCancleBtn.Location = new System.Drawing.Point(103, 88);
            this.PickUpCancleBtn.Name = "PickUpCancleBtn";
            this.PickUpCancleBtn.Size = new System.Drawing.Size(75, 23);
            this.PickUpCancleBtn.TabIndex = 1;
            this.PickUpCancleBtn.Text = "픽업 취소";
            this.PickUpCancleBtn.UseVisualStyleBackColor = true;
            this.PickUpCancleBtn.Click += new System.EventHandler(this.PickUpCancleBtn_Click);
            // 
            // PickUpBtn
            // 
            this.PickUpBtn.Location = new System.Drawing.Point(9, 88);
            this.PickUpBtn.Name = "PickUpBtn";
            this.PickUpBtn.Size = new System.Drawing.Size(75, 23);
            this.PickUpBtn.TabIndex = 0;
            this.PickUpBtn.Text = "주문 픽업";
            this.PickUpBtn.UseVisualStyleBackColor = true;
            this.PickUpBtn.Click += new System.EventHandler(this.PickUpBtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ReloadBtn);
            this.groupBox1.Controls.Add(this.OrderCounter);
            this.groupBox1.Controls.Add(this.OrderDataGridView);
            this.groupBox1.Location = new System.Drawing.Point(6, 87);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(489, 307);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "주문 목록";
            // 
            // ReloadBtn
            // 
            this.ReloadBtn.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ReloadBtn.Location = new System.Drawing.Point(16, 14);
            this.ReloadBtn.Name = "ReloadBtn";
            this.ReloadBtn.Size = new System.Drawing.Size(23, 26);
            this.ReloadBtn.TabIndex = 9;
            this.ReloadBtn.Text = "↺";
            this.ReloadBtn.UseVisualStyleBackColor = true;
            this.ReloadBtn.Click += new System.EventHandler(this.ReloadBtn_Click);
            // 
            // OrderCounter
            // 
            this.OrderCounter.AutoSize = true;
            this.OrderCounter.Location = new System.Drawing.Point(390, 31);
            this.OrderCounter.Name = "OrderCounter";
            this.OrderCounter.Size = new System.Drawing.Size(87, 12);
            this.OrderCounter.TabIndex = 3;
            this.OrderCounter.Text = "주문 : 총 000개";
            // 
            // OrderDataGridView
            // 
            this.OrderDataGridView.AllowUserToAddRows = false;
            this.OrderDataGridView.AllowUserToDeleteRows = false;
            this.OrderDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.OrderDataGridView.Location = new System.Drawing.Point(16, 46);
            this.OrderDataGridView.Name = "OrderDataGridView";
            this.OrderDataGridView.RowHeadersVisible = false;
            this.OrderDataGridView.RowTemplate.Height = 23;
            this.OrderDataGridView.Size = new System.Drawing.Size(461, 241);
            this.OrderDataGridView.TabIndex = 0;
            this.OrderDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.OrdersDataGridView_CellClick);
            // 
            // LoginGroup
            // 
            this.LoginGroup.Controls.Add(this.SignUpBtn);
            this.LoginGroup.Controls.Add(this.LoginBtn);
            this.LoginGroup.Location = new System.Drawing.Point(296, 6);
            this.LoginGroup.Name = "LoginGroup";
            this.LoginGroup.Size = new System.Drawing.Size(199, 75);
            this.LoginGroup.TabIndex = 4;
            this.LoginGroup.TabStop = false;
            this.LoginGroup.Text = "로그인";
            // 
            // SignUpBtn
            // 
            this.SignUpBtn.Location = new System.Drawing.Point(112, 30);
            this.SignUpBtn.Name = "SignUpBtn";
            this.SignUpBtn.Size = new System.Drawing.Size(75, 23);
            this.SignUpBtn.TabIndex = 2;
            this.SignUpBtn.Text = "회원가입";
            this.SignUpBtn.UseVisualStyleBackColor = true;
            this.SignUpBtn.Click += new System.EventHandler(this.SignUpButton_Click);
            // 
            // LoginBtn
            // 
            this.LoginBtn.Location = new System.Drawing.Point(17, 30);
            this.LoginBtn.Name = "LoginBtn";
            this.LoginBtn.Size = new System.Drawing.Size(75, 23);
            this.LoginBtn.TabIndex = 1;
            this.LoginBtn.Text = "로그인";
            this.LoginBtn.UseVisualStyleBackColor = true;
            this.LoginBtn.Click += new System.EventHandler(this.LoginButton_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(501, 740);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "마이페이지";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.DriverOrdersCompleteCounter);
            this.groupBox4.Controls.Add(this.DriverOrdersCompleteDataGridView);
            this.groupBox4.Location = new System.Drawing.Point(6, 112);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(489, 307);
            this.groupBox4.TabIndex = 12;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "배달완료 기록";
            // 
            // DriverOrdersCompleteCounter
            // 
            this.DriverOrdersCompleteCounter.AutoSize = true;
            this.DriverOrdersCompleteCounter.Location = new System.Drawing.Point(340, 31);
            this.DriverOrdersCompleteCounter.Name = "DriverOrdersCompleteCounter";
            this.DriverOrdersCompleteCounter.Size = new System.Drawing.Size(137, 12);
            this.DriverOrdersCompleteCounter.TabIndex = 3;
            this.DriverOrdersCompleteCounter.Text = "배달 완료한 주문 : 총 개";
            // 
            // DriverOrdersCompleteDataGridView
            // 
            this.DriverOrdersCompleteDataGridView.AllowUserToAddRows = false;
            this.DriverOrdersCompleteDataGridView.AllowUserToDeleteRows = false;
            this.DriverOrdersCompleteDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DriverOrdersCompleteDataGridView.Location = new System.Drawing.Point(16, 46);
            this.DriverOrdersCompleteDataGridView.Name = "DriverOrdersCompleteDataGridView";
            this.DriverOrdersCompleteDataGridView.RowHeadersVisible = false;
            this.DriverOrdersCompleteDataGridView.RowTemplate.Height = 23;
            this.DriverOrdersCompleteDataGridView.Size = new System.Drawing.Size(461, 241);
            this.DriverOrdersCompleteDataGridView.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.SignOutBtn);
            this.groupBox5.Controls.Add(this.UpdateBtn);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.DriverIdTxt);
            this.groupBox5.Location = new System.Drawing.Point(295, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(200, 100);
            this.groupBox5.TabIndex = 11;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "사용자";
            // 
            // SignOutBtn
            // 
            this.SignOutBtn.Location = new System.Drawing.Point(119, 57);
            this.SignOutBtn.Name = "SignOutBtn";
            this.SignOutBtn.Size = new System.Drawing.Size(75, 23);
            this.SignOutBtn.TabIndex = 13;
            this.SignOutBtn.Text = "회원 탈퇴";
            this.SignOutBtn.UseVisualStyleBackColor = true;
            this.SignOutBtn.Click += new System.EventHandler(this.SignOutBtn_Click);
            // 
            // UpdateBtn
            // 
            this.UpdateBtn.Location = new System.Drawing.Point(6, 57);
            this.UpdateBtn.Name = "UpdateBtn";
            this.UpdateBtn.Size = new System.Drawing.Size(101, 23);
            this.UpdateBtn.TabIndex = 12;
            this.UpdateBtn.Text = "회원 정보 수정";
            this.UpdateBtn.UseVisualStyleBackColor = true;
            this.UpdateBtn.Click += new System.EventHandler(this.UpdateBtn_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 12);
            this.label4.TabIndex = 11;
            this.label4.Text = "ID : ";
            // 
            // DriverIdTxt
            // 
            this.DriverIdTxt.Location = new System.Drawing.Point(70, 20);
            this.DriverIdTxt.Name = "DriverIdTxt";
            this.DriverIdTxt.ReadOnly = true;
            this.DriverIdTxt.Size = new System.Drawing.Size(100, 21);
            this.DriverIdTxt.TabIndex = 10;
            // 
            // DriverForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(527, 781);
            this.Controls.Add(this.tabControl1);
            this.Name = "DriverForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "안심 대행 배달 기사";
            this.Load += new System.EventHandler(this.DriverForm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DriverOrdersDataGridView)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OrderDataGridView)).EndInit();
            this.LoginGroup.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DriverOrdersCompleteDataGridView)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox LoginGroup;
        private System.Windows.Forms.Button SignUpBtn;
        private System.Windows.Forms.Button LoginBtn;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button PickUpCancleBtn;
        private System.Windows.Forms.Button PickUpBtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox SelcetOrderTxt;
        private System.Windows.Forms.Label OrderCounter;
        internal System.Windows.Forms.DataGridView OrderDataGridView;
        private System.Windows.Forms.Button ReloadBtn;
        private System.Windows.Forms.Label DriverOrdersCounter;
        private System.Windows.Forms.Label label1;
        internal System.Windows.Forms.DataGridView DriverOrdersDataGridView;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox DriverOrdertxt;
        private System.Windows.Forms.Button EndBtn;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button SignOutBtn;
        private System.Windows.Forms.Button UpdateBtn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox DriverIdTxt;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label DriverOrdersCompleteCounter;
        internal System.Windows.Forms.DataGridView DriverOrdersCompleteDataGridView;
    }
}

