﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oracle.DataAccess.Client;//ADO.Net 개체 참조
using System.Data; //DataSet 개체 참조
using System.Windows.Forms; //MessageBox 개체 참조

namespace TeamProjectDriver
{
    // 텍스트 공백 제거 클래스
    public static class TextTrim
    {
        // 문자열의 앞뒤 공백을 제거하는 메서드
        public static string TrimWhitespace(string input)
        {
            // 앞뒤의 여백을 제거합니다.
            return input?.Trim();
        }
    }

    // 데이터베이스 기능을 제공하는 클래스
    class DBClass
    {
        private OracleConnection connection; // 데이터 베이스 연결 담당하는 객체
        private OracleCommand dCom; // 데이터베이스 쿼리를 실행하는 객체
        private OracleDataAdapter dA; // 데이터베이스에서 데이터를 가져오는 객체
        private DataSet dS; // 데이터를 저장하는 객체

        // 오라클 데이터베이스 연결 문자열
        private const string connectionString = "User Id=hong1; Password=1111; Data Source=(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = localhost)(PORT = 1521)) (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = xe) ) );";
        // 사용자 인증 쿼리
        private const string authenticateDriverQuery = "SELECT COUNT(*) FROM DriverInfo WHERE DriverId = :DriverId AND DPassword = :DPassword";
        // 중복 사용자 아이디 체크 쿼리
        private const string checkDuplicateDriverIdQuery = "SELECT COUNT(*) FROM DriverInfo WHERE DriverId = :DriverId";
        // 사용자 등록 쿼리
        private const string registerDriverQuery = "INSERT INTO DriverInfo (DriverId, DPassword, DName, DPhone, SignUpDate) VALUES (:DriverId, :DPassword, :DName, :DPhone, :SignUpDate)";


        public OracleCommand DCom { get { return dCom; } set { dCom = value; } }
        public OracleDataAdapter DA { get { return dA; } set { dA = value; } }
        public DataSet DS { get { return dS; } set { dS = value; } }

        public DBClass()
        {
            connection = new OracleConnection(connectionString);
            dCom = new OracleCommand();
            dCom.Connection = connection;
            dA = new OracleDataAdapter();
            DS = new DataSet();
            DS.Tables.Add("USERINFO");
            DS.Tables.Add("ORDERS");
            DS.Tables.Add("INQUIRIES");
            DS.Tables.Add("DriverInfo");
            DS.Tables.Add("DOrders");
        }

        // 데이터베이스 연결 메서드
        public bool ConnectToDatabase()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("DB 연결 오류: " + ex.Message);
                return false;
            }
        }

        // 일반 쿼리 실행 메서드
        private int ExecuteQuery(string query, OracleParameter[] parameters)
        {
            // OracleCommand를 사용하여 쿼리를 실행하고 영향을 받은 행 수를 반환
            using (OracleCommand command = new OracleCommand(query, connection))
            {
                command.Parameters.AddRange(parameters);
                return command.ExecuteNonQuery();
            }
        }

        // 스칼라 쿼리 실행 메서드
        private int ExecuteScalarQuery(string query, OracleParameter[] parameters)
        {
            // OracleCommand를 사용하여 스칼라 쿼리를 실행하고 결과를 정수로 반환
            using (OracleCommand command = new OracleCommand(query, connection))
            {
                command.Parameters.AddRange(parameters);
                return Convert.ToInt32(command.ExecuteScalar());
            }
        }

        // 데이터베이스 연결 해제
        public void DisconnectFromDatabase()
        {
            if (connection.State == ConnectionState.Open)
                connection.Close();
        }

        // 예외 처리 메서드
        private void HandleException(string errorMessage, Exception ex)
        {
            // 예외 던지기 대신 호출자에서 처리하도록 변경
            throw new Exception(errorMessage, ex);
        }

        // 사용자 인증
        public bool AuthenticateDriver(string driverId, string dPassword)
        {
            try
            {
                // TextTrimdmf 사용하여 공백 제거
                driverId = TextTrim.TrimWhitespace(driverId);
                dPassword = TextTrim.TrimWhitespace(dPassword);

                // 인증 쿼리 실행 후 결과를 반환
                OracleParameter[] parameters = {
                new OracleParameter(":DriverId", OracleDbType.Varchar2) { Value = driverId },
                new OracleParameter(":DPassword", OracleDbType.Varchar2) { Value = dPassword }
            };

                return ExecuteScalarQuery(authenticateDriverQuery, parameters) > 0;
            }
            catch (Exception ex)
            {
                HandleException("인증 오류", ex);
                return false;
            }
        }

        // 중복 사용자 아이디 체크
        public bool CheckDuplicateDriverId(string driverId)
        {
            try
            {
                // 중복 체크 쿼리 실행 후 결과를 반환
                OracleParameter[] parameters = {
                new OracleParameter(":DriverId", OracleDbType.Varchar2) { Value = driverId }
            };

                return ExecuteScalarQuery(checkDuplicateDriverIdQuery, parameters) > 0;
            }
            catch (Exception ex)
            {
                HandleException("중복 체크 오류", ex);
                return false;
            }
        }

        // 사용자 등록
        // 회원가입 실패 시 테이블에 값이 저장되는 문제 수정
        public bool RegisterDriver(string driverId, string dPassword, string dName, string dPhone)
        {
            driverId = TextTrim.TrimWhitespace(driverId);
            dPassword = TextTrim.TrimWhitespace(dPassword);
            dName = TextTrim.TrimWhitespace(dName);
            dPhone = TextTrim.TrimWhitespace(dPhone);

            try
            {
                using (OracleTransaction transaction = connection.BeginTransaction())
                {
                    try
                    {
                        OracleParameter[] parameters = {
                        new OracleParameter(":UserId", OracleDbType.Varchar2) { Value = driverId },
                        new OracleParameter(":Password", OracleDbType.Varchar2) { Value = dPassword },
                        new OracleParameter(":Name", OracleDbType.Varchar2) { Value = dName },
                        new OracleParameter(":Phone", OracleDbType.Varchar2) { Value = dPhone },
                        new OracleParameter(":SignUpDate", OracleDbType.Date) { Value = DateTime.Now },
                    };

                        dCom.CommandText = registerDriverQuery;
                        dCom.Parameters.AddRange(parameters);
                        dCom.ExecuteNonQuery();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        Console.WriteLine($"회원가입 중 오류 발생: {ex.Message}");
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"회원가입 중 오류 발생: {ex.Message}");
                return false;
            }
        }
    }
}